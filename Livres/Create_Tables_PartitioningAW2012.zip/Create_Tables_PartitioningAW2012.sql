/*
	Expand the data and log file first.
	The table will be >100M rows by defaul, requiring about 100 GB for the database
	You can decrease the size by changing the values used for the data load below
*/
USE [master]
GO
ALTER DATABASE [AdventureWorks2012] 
	MODIFY FILE ( NAME = N'[AdventureWorks2012_Data]', 
	SIZE = 40960MB , 
	FILEGROWTH = 1024MB );
GO
ALTER DATABASE [AdventureWorks2012] 
	MODIFY FILE ( NAME = N'[AdventureWorks2012_Log]', 
	SIZE = 4096MB , 
	FILEGROWTH = 1024MB );
GO

SET NOCOUNT ON;

USE [AdventureWorks2012];
GO

/*
	Create the non-partitioned table
*/
CREATE TABLE [Sales].[Big_SalesOrderHeader](
	[SalesOrderID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[RevisionNumber] [tinyint] NOT NULL,
	[OrderDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[ShipDate] [datetime] NULL,
	[Status] [tinyint] NOT NULL,
	[OnlineOrderFlag] [dbo].[Flag] NOT NULL,
	[SalesOrderNumber]  AS (isnull(N'SO'+CONVERT([nvarchar](23),[SalesOrderID]),N'*** ERROR ***')),
	[PurchaseOrderNumber] [dbo].[OrderNumber] NULL,
	[AccountNumber] [dbo].[AccountNumber] NULL,
	[CustomerID] [int] NOT NULL,
	[SalesPersonID] [int] NULL,
	[TerritoryID] [int] NULL,
	[BillToAddressID] [int] NOT NULL,
	[ShipToAddressID] [int] NOT NULL,
	[ShipMethodID] [int] NOT NULL,
	[CreditCardID] [int] NULL,
	[CreditCardApprovalCode] [varchar](15) NULL,
	[CurrencyRateID] [int] NULL,
	[SubTotal] [money] NOT NULL,
	[TaxAmt] [money] NOT NULL,
	[Freight] [money] NOT NULL,
	[TotalDue]  AS (isnull(([SubTotal]+[TaxAmt])+[Freight],(0))),
	[Comment] [nvarchar](128) NULL,
	[rowguid] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
 CONSTRAINT [PK_Big_SalesOrderHeader_SalesOrderID] PRIMARY KEY CLUSTERED 
(
	[SalesOrderID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/*
	Load data into the non-partitioned table
	***Adjust the WHILE loop counter below to decrease the
	number of rows in the table.  Each loop adds just over 
	24,000 rows to the table.
*/
USE [AdventureWorks2012];
GO

SET NOCOUNT ON;

DECLARE @Year1 TINYINT = 5;
DECLARE @Year2 TINYINT = 6;
DECLARE @YearCount TINYINT = 0;
DECLARE @Loops SMALLINT = 0;

WHILE @YearCount < 1
BEGIN
	WHILE @Loops < 5000 --adjust this to decrease or increase the number of rows in the table
		BEGIN
			INSERT INTO [Sales].[Big_SalesOrderHeader]
				([RevisionNumber]
				,[OrderDate]
				,[DueDate]
				,[ShipDate]
				,[Status]
				,[OnlineOrderFlag]
				,[PurchaseOrderNumber]
				,[AccountNumber]
				,[CustomerID]
				,[SalesPersonID]
				,[TerritoryID]
				,[BillToAddressID]
				,[ShipToAddressID]
				,[ShipMethodID]
				,[CreditCardID]
				,[CreditCardApprovalCode]
				,[CurrencyRateID]
				,[SubTotal]
				,[TaxAmt]
				,[Freight]
				,[Comment]
				,[rowguid]
				,[ModifiedDate])
			SELECT 
				[RevisionNumber]
				,DATEADD(YY, @Year1, [OrderDate])
				,DATEADD(YY, @Year1, [DueDate])
				,DATEADD(YY, @Year1, [ShipDate])
				,[Status]
				,[OnlineOrderFlag]
				,[PurchaseOrderNumber]
				,[AccountNumber]
				,[CustomerID]
				,[SalesPersonID]
				,[TerritoryID]
				,[BillToAddressID]
				,[ShipToAddressID]
				,[ShipMethodID]
				,[CreditCardID]
				,[CreditCardApprovalCode]
				,[CurrencyRateID]
				,[SubTotal]
				,[TaxAmt]
				,[Freight]
				,[Comment]
				,[rowguid]
				,DATEADD(YY, @Year1, [ModifiedDate])
			FROM [Sales].[SalesOrderHeader]
			WHERE [OrderDate] BETWEEN '2007-07-01' AND '2008-07-31';
			CHECKPOINT;
			INSERT INTO [Sales].[Big_SalesOrderHeader]
				([RevisionNumber]
				,[OrderDate]
				,[DueDate]
				,[ShipDate]
				,[Status]
				,[OnlineOrderFlag]
				,[PurchaseOrderNumber]
				,[AccountNumber]
				,[CustomerID]
				,[SalesPersonID]
				,[TerritoryID]
				,[BillToAddressID]
				,[ShipToAddressID]
				,[ShipMethodID]
				,[CreditCardID]
				,[CreditCardApprovalCode]
				,[CurrencyRateID]
				,[SubTotal]
				,[TaxAmt]
				,[Freight]
				,[Comment]
				,[rowguid]
				,[ModifiedDate])
			SELECT 
				[RevisionNumber]
				,DATEADD(YY, @Year2, [OrderDate])
				,DATEADD(YY, @Year2, [DueDate])
				,DATEADD(YY, @Year2, [ShipDate])
				,[Status]
				,[OnlineOrderFlag]
				,[PurchaseOrderNumber]
				,[AccountNumber]
				,[CustomerID]
				,[SalesPersonID]
				,[TerritoryID]
				,[BillToAddressID]
				,[ShipToAddressID]
				,[ShipMethodID]
				,[CreditCardID]
				,[CreditCardApprovalCode]
				,[CurrencyRateID]
				,[SubTotal]
				,[TaxAmt]
				,[Freight]
				,[Comment]
				,[rowguid]
				,DATEADD(YY, @Year2, [ModifiedDate])
			FROM [Sales].[SalesOrderHeader]
			WHERE [OrderDate] BETWEEN '2007-07-01' AND '2007-07-31';
			CHECKPOINT;
		SET @Loops = @Loops + 1;
		END
	  SET @YearCount = @YearCount + 1;
	  SET @Year1 = @Year1 + 1;
	  SET @Year2 = @Year2 + 1;
	  SET @Loops = 0;
END


USE [AdventureWorks2012];
GO

/*
	Add filegroups for partitioned table
*/
ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG1];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG2];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG3];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG4];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG5];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG6];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG7];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG8];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG9];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG10];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG11];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG12];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG13];

ALTER DATABASE [AdventureWorks2012]
	ADD FILEGROUP [FG14];

/* 
	Add files for each filegroup
	***Alter path as necessary
*/
ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH1',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH1.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG1];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH2',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH2.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG2];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH3',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH3.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG3];


ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH4',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH4.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG4];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH5',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH5.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG5];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH6',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH6.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG6];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH7',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH7.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG7];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH8',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH8.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG8];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH9',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH9.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG9];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH10',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH10.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG10];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH11',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH11.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG11];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH12',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH12.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG12];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH13',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH13.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG13];

ALTER DATABASE [AdventureWorks2012]
	ADD FILE 
	  (NAME = N'SOH14',
	  FILENAME = N'F:\Databases\AdventureWorks2012\SOH14.ndf',
	  SIZE = 4096MB,
	  FILEGROWTH = 1024MB)
	TO FILEGROUP [FG14];


/* 
	Create the partition function 
*/
CREATE PARTITION FUNCTION OrderDateRangePFN(DATETIME)
AS 
RANGE RIGHT FOR VALUES (
			'20120801', --everything in July 2012
			'20120901', --everything in Aug 2012
			'20121001', --everything in Sept 2012
			'20121101', --everything in Oct 2012
			'20121201', --everything in Nov 2012
			'20130101', --everything in Dec 2012
			'20130201', --everything in Jan 2013
			'20130301', --everything in Feb 2013
			'20130401', --everything in Mar 2013
			'20130501', --everything in Apr 2013
			'20130601', --everything in May 2013
			'20130701', --everything in June 2013
			'20130801'  --everything in July 2013
			); 

/* 
	Create the parition scheme 
*/
CREATE PARTITION SCHEME [OrderDateRangePScheme]
AS 
PARTITION OrderDateRangePFN TO 
( [FG1], [FG2], [FG3], [FG4], [FG5], [FG6], [FG7], [FG8], [FG9], [FG10], [FG11], [FG12], [FG13], [FG14] );
GO


/*
	Create the partitioned table
*/
CREATE TABLE [AdventureWorks2012].[Sales].[Part_SalesOrderHeader]  
(
	[SalesOrderID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[RevisionNumber] [tinyint] NOT NULL,
	[OrderDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[ShipDate] [datetime] NULL,
	[Status] [tinyint] NOT NULL,
	[OnlineOrderFlag] [dbo].[Flag] NOT NULL,
	[SalesOrderNumber]  AS (isnull(N'SO'+CONVERT([nvarchar](23),[SalesOrderID]),N'*** ERROR ***')),
	[PurchaseOrderNumber] [dbo].[OrderNumber] NULL,
	[AccountNumber] [dbo].[AccountNumber] NULL,
	[CustomerID] [int] NOT NULL,
	[SalesPersonID] [int] NULL,
	[TerritoryID] [int] NULL,
	[BillToAddressID] [int] NOT NULL,
	[ShipToAddressID] [int] NOT NULL,
	[ShipMethodID] [int] NOT NULL,
	[CreditCardID] [int] NULL,
	[CreditCardApprovalCode] [varchar](15) NULL,
	[CurrencyRateID] [int] NULL,
	[SubTotal] [money] NOT NULL,
	[TaxAmt] [money] NOT NULL,
	[Freight] [money] NOT NULL,
	[TotalDue]  AS (isnull(([SubTotal]+[TaxAmt])+[Freight],(0))),
	[Comment] [nvarchar](128) NULL,
	[rowguid] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[ModifiedDate] [datetime] NOT NULL
) ON OrderDateRangePScheme([OrderDate]);
GO

 
/*
	Load data into the partitioned table
	***Adjust the WHILE loop counter below to decrease the
	number of rows in the table.  Each loop adds just over 
	24,000 rows to the table.
*/
USE [AdventureWorks2012];
GO

SET NOCOUNT ON;

DECLARE @Year1 TINYINT = 5;
DECLARE @Year2 TINYINT = 6;
DECLARE @YearCount TINYINT = 0;
DECLARE @Loops SMALLINT = 0;

WHILE @YearCount < 1
BEGIN
	WHILE @Loops < 5000 --adjust this to decrease or increase the number of rows in the table
		BEGIN
			INSERT INTO [Sales].[Part_SalesOrderHeader]
				([RevisionNumber]
				,[OrderDate]
				,[DueDate]
				,[ShipDate]
				,[Status]
				,[OnlineOrderFlag]
				,[PurchaseOrderNumber]
				,[AccountNumber]
				,[CustomerID]
				,[SalesPersonID]
				,[TerritoryID]
				,[BillToAddressID]
				,[ShipToAddressID]
				,[ShipMethodID]
				,[CreditCardID]
				,[CreditCardApprovalCode]
				,[CurrencyRateID]
				,[SubTotal]
				,[TaxAmt]
				,[Freight]
				,[Comment]
				,[rowguid]
				,[ModifiedDate])
			SELECT 
				[RevisionNumber]
				,DATEADD(YY, @Year1, [OrderDate])
				,DATEADD(YY, @Year1, [DueDate])
				,DATEADD(YY, @Year1, [ShipDate])
				,[Status]
				,[OnlineOrderFlag]
				,[PurchaseOrderNumber]
				,[AccountNumber]
				,[CustomerID]
				,[SalesPersonID]
				,[TerritoryID]
				,[BillToAddressID]
				,[ShipToAddressID]
				,[ShipMethodID]
				,[CreditCardID]
				,[CreditCardApprovalCode]
				,[CurrencyRateID]
				,[SubTotal]
				,[TaxAmt]
				,[Freight]
				,[Comment]
				,[rowguid]
				,DATEADD(YY, @Year1, [ModifiedDate])
			FROM [Sales].[SalesOrderHeader]
			WHERE [OrderDate] BETWEEN '2007-07-01' AND '2008-07-31';
			CHECKPOINT;
			INSERT INTO [Sales].[Part_SalesOrderHeader]
				([RevisionNumber]
				,[OrderDate]
				,[DueDate]
				,[ShipDate]
				,[Status]
				,[OnlineOrderFlag]
				,[PurchaseOrderNumber]
				,[AccountNumber]
				,[CustomerID]
				,[SalesPersonID]
				,[TerritoryID]
				,[BillToAddressID]
				,[ShipToAddressID]
				,[ShipMethodID]
				,[CreditCardID]
				,[CreditCardApprovalCode]
				,[CurrencyRateID]
				,[SubTotal]
				,[TaxAmt]
				,[Freight]
				,[Comment]
				,[rowguid]
				,[ModifiedDate])
			SELECT 
				[RevisionNumber]
				,DATEADD(YY, @Year2, [OrderDate])
				,DATEADD(YY, @Year2, [DueDate])
				,DATEADD(YY, @Year2, [ShipDate])
				,[Status]
				,[OnlineOrderFlag]
				,[PurchaseOrderNumber]
				,[AccountNumber]
				,[CustomerID]
				,[SalesPersonID]
				,[TerritoryID]
				,[BillToAddressID]
				,[ShipToAddressID]
				,[ShipMethodID]
				,[CreditCardID]
				,[CreditCardApprovalCode]
				,[CurrencyRateID]
				,[SubTotal]
				,[TaxAmt]
				,[Freight]
				,[Comment]
				,[rowguid]
				,DATEADD(YY, @Year2, [ModifiedDate])
			FROM [Sales].[SalesOrderHeader]
			WHERE [OrderDate] BETWEEN '2007-07-01' AND '2007-07-31';
			CHECKPOINT;
		SET @Loops = @Loops + 1;
		END
	  SET @YearCount = @YearCount + 1;
	  SET @Year1 = @Year1 + 1;
	  SET @Year2 = @Year2 + 1;
	  SET @Loops = 0;
END


/* 
	Add the clustered index to the partitioned table
*/
ALTER TABLE Sales.Part_SalesOrderHeader
ADD CONSTRAINT Part_SOH_PK
   PRIMARY KEY CLUSTERED ([OrderDate], [SalesOrderID])
   ON OrderDateRangePScheme([OrderDate])
GO


/* 
	Check to see how much data resides in each partition, and 
	the minimum and maximum OrderDate for each partition.
	If a partition does not have any rows, it will not be returned by this query. 
*/
SELECT $partition.[OrderDateRangePFN]([o].[OrderDate]) 
         AS [Partition Number]
   , MIN([o].[OrderDate]) AS [Min Order Date]
   , MAX([o].[OrderDate]) AS [Max Order Date]
   , COUNT(*) AS [Rows In Partition]
FROM [Sales].[Part_SalesOrderHeader] AS [o]
GROUP BY $partition.[OrderDateRangePFN]([o].[OrderDate])
ORDER BY [Partition Number];
GO


/*
	For purposes of this post and included queries, you can stop here.
	If you want to step through switching one partition out, and a new one
	out, continue through the end of the script.
	You can do this and then run the queries in the script, but realize
	the output and numbers will vary.
*/


/* 
	Create the staging table for August 2013 data
*/
CREATE TABLE [AdventureWorks2012].[Sales].[Aug2013_SalesOrderHeader]  
(
	[SalesOrderID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[RevisionNumber] [tinyint] NOT NULL,
	[OrderDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[ShipDate] [datetime] NULL,
	[Status] [tinyint] NOT NULL,
	[OnlineOrderFlag] [dbo].[Flag] NOT NULL,
	[SalesOrderNumber]  AS (isnull(N'SO'+CONVERT([nvarchar](23),[SalesOrderID]),N'*** ERROR ***')),
	[PurchaseOrderNumber] [dbo].[OrderNumber] NULL,
	[AccountNumber] [dbo].[AccountNumber] NULL,
	[CustomerID] [int] NOT NULL,
	[SalesPersonID] [int] NULL,
	[TerritoryID] [int] NULL,
	[BillToAddressID] [int] NOT NULL,
	[ShipToAddressID] [int] NOT NULL,
	[ShipMethodID] [int] NOT NULL,
	[CreditCardID] [int] NULL,
	[CreditCardApprovalCode] [varchar](15) NULL,
	[CurrencyRateID] [int] NULL,
	[SubTotal] [money] NOT NULL,
	[TaxAmt] [money] NOT NULL,
	[Freight] [money] NOT NULL,
	[TotalDue]  AS (isnull(([SubTotal]+[TaxAmt])+[Freight],(0))),
	[Comment] [nvarchar](128) NULL,
	[rowguid] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[ModifiedDate] [datetime] NOT NULL
) ON [FG14]
GO

/* 
	Load August 2013 data 
	***Adjust the value after GO below to decrease the
	number of rows in the table.  Each iteration adds just over 
	24,000 rows to the table.
*/
INSERT INTO [Sales].[Aug2013_SalesOrderHeader]
	([RevisionNumber]
	,[OrderDate]
	,[DueDate]
	,[ShipDate]
	,[Status]
	,[OnlineOrderFlag]
	,[PurchaseOrderNumber]
	,[AccountNumber]
	,[CustomerID]
	,[SalesPersonID]
	,[TerritoryID]
	,[BillToAddressID]
	,[ShipToAddressID]
	,[ShipMethodID]
	,[CreditCardID]
	,[CreditCardApprovalCode]
	,[CurrencyRateID]
	,[SubTotal]
	,[TaxAmt]
	,[Freight]
	,[Comment]
	,[rowguid]
	,[ModifiedDate])
SELECT 
	[RevisionNumber]
	,DATEADD(YY, 6, [OrderDate])
	,DATEADD(YY, 6, [DueDate])
	,DATEADD(YY, 6, [ShipDate])
	,[Status]
	,[OnlineOrderFlag]
	,[PurchaseOrderNumber]
	,[AccountNumber]
	,[CustomerID]
	,[SalesPersonID]
	,[TerritoryID]
	,[BillToAddressID]
	,[ShipToAddressID]
	,[ShipMethodID]
	,[CreditCardID]
	,[CreditCardApprovalCode]
	,[CurrencyRateID]
	,[SubTotal]
	,[TaxAmt]
	,[Freight]
	,[Comment]
	,[rowguid]
	,DATEADD(YY, 6, [ModifiedDate])
FROM Sales.SalesOrderHeader
WHERE OrderDate BETWEEN '2007-08-01' AND '2007-08-31';
CHECKPOINT;
GO 5000 --adjust this to decrease or increase the number of rows in the table


/* 
	Add the clustered index to the staging table,
	note that it has the same key columns as the partitioned table
*/
ALTER TABLE Sales.Aug2013_SalesOrderHeader
ADD CONSTRAINT SOH_Aug2013PK 
PRIMARY KEY CLUSTERED (OrderDate, SalesOrderID)
ON [FG14]
GO


/* 
	Create a second staging table which is empty.
	This will hold the July 2012 data which will switch out.
*/
CREATE TABLE [AdventureWorks2012].[Sales].[July2012_SalesOrderHeader]  
(
	[SalesOrderID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[RevisionNumber] [tinyint] NOT NULL,
	[OrderDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[ShipDate] [datetime] NULL,
	[Status] [tinyint] NOT NULL,
	[OnlineOrderFlag] [dbo].[Flag] NOT NULL,
	[SalesOrderNumber]  AS (isnull(N'SO'+CONVERT([nvarchar](23),[SalesOrderID]),N'*** ERROR ***')),
	[PurchaseOrderNumber] [dbo].[OrderNumber] NULL,
	[AccountNumber] [dbo].[AccountNumber] NULL,
	[CustomerID] [int] NOT NULL,
	[SalesPersonID] [int] NULL,
	[TerritoryID] [int] NULL,
	[BillToAddressID] [int] NOT NULL,
	[ShipToAddressID] [int] NOT NULL,
	[ShipMethodID] [int] NOT NULL,
	[CreditCardID] [int] NULL,
	[CreditCardApprovalCode] [varchar](15) NULL,
	[CurrencyRateID] [int] NULL,
	[SubTotal] [money] NOT NULL,
	[TaxAmt] [money] NOT NULL,
	[Freight] [money] NOT NULL,
	[TotalDue]  AS (isnull(([SubTotal]+[TaxAmt])+[Freight],(0))),
	[Comment] [nvarchar](128) NULL,
	[rowguid] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[ModifiedDate] [datetime] NOT NULL
) ON [FG1]
GO


/* 
	Add the clustered index to the staging table,
	note again that it has the same key columns as the partitioned table
*/
ALTER TABLE [Sales].[July2012_SalesOrderHeader] 
ADD CONSTRAINT SOH_July2012_PK 
PRIMARY KEY CLUSTERED (OrderDate, SalesOrderID)
ON [FG1]
GO


/* 
	Switch the July 2012 data into the [July2012_SalesOrderHeader] staging table
*/
ALTER TABLE Sales.Part_SalesOrderHeader
SWITCH PARTITION 1
TO [Sales].[July2012_SalesOrderHeader]
GO



/* 
	Alter the partition function to remove the boundary point for July 2012 
*/

ALTER PARTITION FUNCTION OrderDateRangePFN()
MERGE RANGE ('20120801')
GO


/* 
	Set the filegroup to use for the next partition
*/

ALTER PARTITION SCHEME OrderDateRangePScheme 
              NEXT USED [FG14]
GO

/* 
	Alter the partition function to add the new boundary point for August 2013 data 
*/
ALTER PARTITION FUNCTION OrderDateRangePFN() 
SPLIT RANGE ('20130901')
GO


/* 
	Add the constraint to the August 2013 staging table
*/
ALTER TABLE Sales.Aug2013_SalesOrderHeader
ADD CONSTRAINT SOH_Aug2013_CK
        CHECK ([OrderDate] >= '20130801' AND [OrderDate] < '20130901')
GO

        
/* 
	Switch the August 2013 data into the partitioned table from staging table
*/

ALTER TABLE [Sales].[Aug2013_SalesOrderHeader]
SWITCH TO Sales.Part_SalesOrderHeader PARTITION 13; 
GO
