/* Order to run the stored procedures for droping and adding foreign keys and indexes. */

/*  Run the first six stored procedures after creating the database structure on the new collation
    and before importing the data with the BCP scripts. */

exec ClearFKScriptsTable
exec ClearIndexScriptsTable

exec FindForeignKeys
exec FindIndexKeys 

exec DropFKConstraints
exec DropIndexes

/*  Import the data with the BCP scripts. */

/*  Run the scripts to recreate the indexes.
    If you run into errors, fix the data and run the script again. */

exec AddIndexes

/*  Once all of the indexes have been recreated, run the script to recreate the foreign keys. */

exec AddFKConstraints
