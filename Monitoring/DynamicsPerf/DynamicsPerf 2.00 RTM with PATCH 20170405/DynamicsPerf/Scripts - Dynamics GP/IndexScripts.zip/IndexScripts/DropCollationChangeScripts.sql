/*  Run this script to remove the tables and stored procedures for the Collation Change. */

drop table dbo.FKScripts
drop table dbo.IndexScripts

drop procedure dbo.ClearFKScriptsTable
drop procedure dbo.ForeignKeyFColumns
drop procedure dbo.ForeignKeyRColumns
drop procedure dbo.FindForeignKeys
drop procedure dbo.DropFKConstraints
drop procedure dbo.AddFKConstraints

drop procedure dbo.ClearIndexScriptsTable
drop procedure dbo.IndexedColumns
drop procedure dbo.IncludedColumns
drop procedure dbo.FindIndexKeys
drop procedure dbo.DropIndexes
drop procedure dbo.AddIndexes
