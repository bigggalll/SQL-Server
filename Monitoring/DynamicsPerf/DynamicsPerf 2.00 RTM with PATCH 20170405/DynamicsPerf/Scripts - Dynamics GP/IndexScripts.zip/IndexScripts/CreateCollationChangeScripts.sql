/*  Create Tables and Stored Procedures for dropping and adding foreign keys and indexes. */

if exists (select * from sysobjects
  where id = object_id('dbo.FKScripts') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
drop table dbo.FKScripts
go
create table dbo.FKScripts (
  TableName char(51) not null,
  FKStatus int not null,
  DropScript varchar(150) not null,
  AddScript varchar(650) not null)
go
grant references,select,insert,delete,update on dbo.FKScripts to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.IndexScripts') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
drop table dbo.IndexScripts
go
create table dbo.IndexScripts (
  TableName char(64) not null,
  IndexName char(64) not null,
  IndexStatus int not null,
  DropScript varchar(160) not null,
  AddScript varchar(3000) not null)
go
grant references,select,insert,delete,update on dbo.FKScripts to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.ClearFKScriptsTable') and sysstat & 0xf = 4)
drop procedure dbo.ClearFKScriptsTable
go
create procedure dbo.ClearFKScriptsTable as
delete from FKScripts
go
grant execute on dbo.ClearFKScriptsTable to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.ForeignKeyFColumns') and sysstat & 0xf = 4)
drop procedure dbo.ForeignKeyFColumns
go
create procedure dbo.ForeignKeyFColumns
@constid int, @fcolumns varchar (200)=NULL out as
declare @fkStatement varchar(255), @firsttime int
select @firsttime=1
set nocount on
declare FColumnsList cursor for
select c.name from syscolumns c, sysforeignkeys fk
  where fk.constid=@constid and c.id = fk.fkeyid and fk.fkey=c.colid
  order by fk.keyno
open FColumnsList
fetch next from FColumnsList into @fkStatement
while (@@fetch_status <> -1) begin
  if (@firsttime = 1) begin
    select @fcolumns = rtrim(@fkStatement)
    select @firsttime=0
    end
  else select @fcolumns = rtrim(@fcolumns) + ',' + rtrim(@fkStatement)
  fetch next from FColumnsList into @fkStatement
  end
deallocate FColumnsList
set nocount off
return
go
grant execute on dbo.ForeignKeyFColumns to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.ForeignKeyRColumns') and sysstat & 0xf = 4)
drop procedure dbo.ForeignKeyRColumns
go
create procedure dbo.ForeignKeyRColumns
@constid int, @rcolumns varchar (200)=NULL out as
declare @fkStatement varchar(255), @firsttime int
select @firsttime=1
set nocount on
declare RColumnsList cursor for
select c.name from syscolumns c, sysforeignkeys fk
  where fk.constid=@constid and c.id = fk.rkeyid and fk.rkey=c.colid
  order by fk.keyno
open RColumnsList
fetch next from RColumnsList into @fkStatement
while (@@fetch_status <> -1) begin
  if (@firsttime = 1) begin
    select @rcolumns = rtrim(@fkStatement)
    select @firsttime=0
    end
  else select @rcolumns = rtrim(@rcolumns) + ',' + rtrim(@fkStatement)
  fetch next from RColumnsList into @fkStatement
  end
deallocate RColumnsList
set nocount off
return
go
grant execute on dbo.ForeignKeyRColumns to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.FindForeignKeys') and sysstat & 0xf = 4)
drop procedure dbo.FindForeignKeys
go
create procedure dbo.FindForeignKeys as
declare @constid int,@fkeyid int,@rkeyid int,@fcolumns char(200),@rcolumns char(200)
declare @fcdropstatement varchar(150),@fcaddstatement varchar(650)

declare BuildFKScripts cursor for
select distinct constid,fkeyid,rkeyid from sysforeignkeys
set nocount on
open BuildFKScripts
fetch next from BuildFKScripts into @constid,@fkeyid,@rkeyid
while (@@fetch_status <> -1) begin
  select @fcdropstatement = 'alter table ' + object_name(@fkeyid) +
    ' drop constraint ' + object_name(@constid)
  exec ForeignKeyFColumns @constid, @fcolumns output
  exec ForeignKeyRColumns @constid, @rcolumns output
  select @fcaddstatement = 'alter table ' + object_name(@fkeyid) +
    ' add constraint ' + object_name(@constid) + ' foreign key (' + rtrim(@fcolumns) +
    ') references ' + object_name(@rkeyid) + ' (' + rtrim(@rcolumns) + ')'
  if not exists (select * from FKScripts where TableName=object_name(@fkeyid)
      and DropScript=@fcdropstatement and AddScript = @fcaddstatement)
    insert into FKScripts values (object_name(@fkeyid),0,rtrim(@fcdropstatement),rtrim(@fcaddstatement))
  fetch next from BuildFKScripts into @constid,@fkeyid,@rkeyid
  end
deallocate BuildFKScripts
set nocount off
go
grant execute on dbo.FindForeignKeys to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.DropFKConstraints') and sysstat & 0xf = 4)
drop procedure dbo.DropFKConstraints
go
create procedure dbo.DropFKConstraints as
declare @dfkcstatement char (150)
declare DFKC cursor for
select DropScript from FKScripts
set nocount on
open DFKC
fetch next from DFKC into @dfkcstatement
while (@@fetch_status <> -1) begin
  exec (@dfkcstatement)
  fetch next from DFKC into @dfkcstatement
  end
deallocate DFKC
set nocount off
go
grant execute on dbo.DropFKConstraints to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.AddFKConstraints') and sysstat & 0xf = 4)
drop procedure dbo.AddFKConstraints
go
create procedure dbo.AddFKConstraints as
declare @afkcstatement char (150), @TableName char(51), @errornum int, @errormsg char(200)
declare AFKC cursor for
select TableName, AddScript from FKScripts where FKStatus = 0
set nocount on
open AFKC
fetch next from AFKC into @TableName, @afkcstatement
while (@@fetch_status <> -1) begin
  begin try
    exec (@afkcstatement)
  end try
  begin catch
    select @errornum = ERROR_NUMBER()
  end catch
  if (@errornum is null) update FKScripts set FKStatus=1 where TableName=@TableName
  else begin
    set @errormsg = 'The Foreign Key on table ' + rtrim(@TableName) + ' failed to be created.'
    print @errormsg
  end
  fetch next from AFKC into @TableName, @afkcstatement
end
deallocate AFKC
set nocount off
go
grant execute on dbo.AddFKConstraints to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.ClearIndexScriptsTable') and sysstat & 0xf = 4)
drop procedure dbo.ClearIndexScriptsTable
go
create procedure dbo.ClearIndexScriptsTable as
delete from IndexScripts
go
grant execute on dbo.ClearIndexScriptsTable to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.IndexedColumns') and sysstat & 0xf = 4)
drop procedure dbo.IndexedColumns
go
create procedure dbo.IndexedColumns
@TableName char(64), @IndexName char(64), @IndexColumns varchar (1000)=NULL out as
declare @IndexStatement varchar(255), @firsttime int
select @firsttime=1
set nocount on
declare IndexColumnsList cursor for
select b.name from sys.index_columns a
  join sys.columns b on a.column_id=b.column_id and a.object_id=b.object_id
  join sys.indexes c on a.index_id=c.index_id and a.object_id=c.object_id
  where c.name = @IndexName and object_name(a.object_id) = @TableName and a.key_ordinal <> 0
  order by a.key_ordinal
open IndexColumnsList
fetch next from IndexColumnsList into @IndexStatement
while (@@fetch_status <> -1) begin
  if (@firsttime = 1) begin
    select @IndexColumns = rtrim(@IndexStatement)
    select @firsttime=0
    end
  else select @IndexColumns = rtrim(@IndexColumns) + ',' + rtrim(@IndexStatement)
  fetch next from IndexColumnsList into @IndexStatement
  end
deallocate IndexColumnsList
set nocount off
return
go
grant execute on dbo.IndexedColumns to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.IncludedColumns') and sysstat & 0xf = 4)
drop procedure dbo.IncludedColumns
go
create procedure dbo.IncludedColumns
@TableName char(64), @IndexName char(64), @IncludeColumns varchar (1000)=NULL out as
declare @IncludeStatement varchar(255), @firsttime int
select @firsttime=1
set nocount on
declare IncludeColumnsList cursor for
select b.name from sys.index_columns a
  join sys.columns b on a.column_id=b.column_id and a.object_id=b.object_id
  join sys.indexes c on a.index_id=c.index_id and a.object_id=c.object_id
  where c.name = @IndexName and object_name(a.object_id) = @TableName
    and a.key_ordinal = 0
  order by a.index_column_id
open IncludeColumnsList
fetch next from IncludeColumnsList into @IncludeStatement
while (@@fetch_status <> -1) begin
  if (@firsttime = 1) begin
    select @IncludeColumns = rtrim(@IncludeStatement)
    select @firsttime=0
    end
  else select @IncludeColumns = rtrim(@IncludeColumns) + ',' + rtrim(@IncludeStatement)
  fetch next from IncludeColumnsList into @IncludeStatement
  end
deallocate IncludeColumnsList
set nocount off
return
go
grant execute on dbo.IncludedColumns to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.FindIndexKeys') and sysstat & 0xf = 4)
drop procedure dbo.FindIndexKeys
go
create procedure dbo.FindIndexKeys as
declare @TableName char(64), @IndexName char(64), @IndexColumns char(1000),@IncludeColumns char(1000)
declare @indropstatement varchar(160),@inaddstatement varchar(3000)
declare BuildFKScripts cursor for
select b.name,a.name from sysindexes a join sysobjects b on a.id=b.id
  where a.status in (0,2,16,18,2050,2066) and a.name is not null and b.type='U' 
  order by b.name,a.name
set nocount on
open BuildFKScripts
fetch next from BuildFKScripts into @TableName,@IndexName
while (@@fetch_status <> -1) begin
  set @IndexColumns=''
  set @IncludeColumns=''
  if ((select status from sysindexes where name=@IndexName and id=object_id(@TableName)) in (2050,2066)) begin
    set @indropstatement = 'alter table ' + rtrim(@TableName) + ' drop constraint ' + rtrim(@IndexName)
    exec IndexedColumns @TableName, @IndexName, @IndexColumns output
    exec IncludedColumns @TableName, @IndexName, @IncludeColumns output
    set @inaddstatement = 'alter table ' + rtrim(@TableName) + ' add constraint ' + rtrim(@IndexName)
    if ((select status from sysindexes where name=@IndexName and id=object_id(@TableName)) = 2066)
      set @inaddstatement = rtrim(@inaddstatement) + ' primary key clustered (' + rtrim(@IndexColumns) + ')'
    else set @inaddstatement = rtrim(@inaddstatement) + ' primary key nonclustered (' + rtrim(@IndexColumns) + ')'
    if (@IncludeColumns <> '') set @inaddstatement = rtrim(@inaddstatement) + ' include (' + rtrim(@IncludeColumns) + ')'
    if not exists (select 1 from IndexScripts where TableName=@TableName
        and DropScript=@indropstatement and AddScript = @inaddstatement)
      insert into IndexScripts values (rtrim(@TableName),rtrim(@IndexName),0,rtrim(@indropstatement),rtrim(@inaddstatement))
    end
  else begin
    set @indropstatement = 'drop index ' + rtrim(@TableName) + '.' + rtrim(@IndexName)
    exec IndexedColumns @TableName, @IndexName, @IndexColumns output
    exec IncludedColumns @TableName, @IndexName, @IncludeColumns output
    set @inaddstatement = 'create'
    if ((select status from sysindexes where name=@IndexName and id=object_id(@TableName)) = 2) 
      set @inaddstatement = rtrim(@inaddstatement) + ' unique'
    if ((select status from sysindexes where name=@IndexName and id=object_id(@TableName)) = 16) 
      set @inaddstatement = rtrim(@inaddstatement) + ' clustered'
    if ((select status from sysindexes where name=@IndexName and id=object_id(@TableName)) = 18) 
      set @inaddstatement = rtrim(@inaddstatement) + ' unique clustered'
    set @inaddstatement = rtrim(@inaddstatement) + ' index ' + rtrim(@IndexName) + ' on '
        + rtrim(@TableName) + '(' + rtrim(@IndexColumns) + ')'
    if (@IncludeColumns <> '') set @inaddstatement = rtrim(@inaddstatement) + ' include (' + rtrim(@IncludeColumns) + ')'
    if not exists (select 1 from IndexScripts where TableName=@TableName
        and DropScript=@indropstatement and AddScript = @inaddstatement)
      insert into IndexScripts values (rtrim(@TableName),rtrim(@IndexName),0,rtrim(@indropstatement),rtrim(@inaddstatement))
    end
  fetch next from BuildFKScripts into @TableName,@IndexName
  end
deallocate BuildFKScripts
set nocount off
go
grant execute on dbo.FindIndexKeys to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.DropIndexes') and sysstat & 0xf = 4)
drop procedure dbo.DropIndexes
go
create procedure dbo.DropIndexes as
declare @dincstatement char (160)
declare DINS cursor for
select DropScript from IndexScripts
set nocount on
open DINS
fetch next from DINS into @dincstatement
while (@@fetch_status <> -1) begin
  exec (@dincstatement)
  fetch next from DINS into @dincstatement
  end
deallocate DINS
set nocount off
go
grant execute on dbo.DropIndexes to DYNGRP
go

if exists (select * from sysobjects
  where id = object_id('dbo.AddIndexes') and sysstat & 0xf = 4)
drop procedure dbo.AddIndexes
go
create procedure dbo.AddIndexes as
declare @TableName char(64), @IndexName char(64), @aincstatement char (3000), @errornum int, @errormsg char(200)
declare AINS cursor for
select TableName, IndexName, AddScript from IndexScripts where IndexStatus=0
set nocount on
open AINS
fetch next from AINS into @TableName, @IndexName, @aincstatement
while (@@fetch_status <> -1) begin
  if exists (select 1 from dbo.sysobjects t1 join dbo.sysindexes t2 on t1.id=t2.id
    where t2.name = @IndexName and t1.id = Object_id(@TableName) and t1.type = 'U')
      update IndexScripts set IndexStatus=1 where TableName=@TableName and IndexName=@IndexName
  else begin
    begin try
      exec (@aincstatement)
    end try
    begin catch
      select @errornum = ERROR_NUMBER()
    end catch
    if (@errornum is null) update IndexScripts set IndexStatus=1 where TableName=@TableName and IndexName=@IndexName
    else begin
      set @errormsg = 'Index ' + rtrim(@IndexName) + ' on table ' + rtrim(@TableName) + ' failed to be created.'
      print @errormsg
    end
  end
  fetch next from AINS into @TableName, @IndexName, @aincstatement
end
deallocate AINS
set nocount off
go
grant execute on dbo.AddIndexes to DYNGRP
go
