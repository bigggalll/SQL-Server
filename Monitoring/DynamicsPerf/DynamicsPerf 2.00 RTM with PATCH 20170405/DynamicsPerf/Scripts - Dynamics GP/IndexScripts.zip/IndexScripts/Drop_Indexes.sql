/* To drop the indexes you created above */
select distinct 'if exists (select * from sysindexes where name = '+''''+'ta'+o.name+c.name+''''+')'+
	' begin drop index '+o.name+'.ta'+o.name+c.name+' end'
	from sysobjects o, syscolumns c, sysindexes i
		where	o.id = c.id
		    and o.type = 'U'
		    and o.id = i.id
		    and (c.name = 'ITEMNMBR')   