/* You might need to run the "DBCC UPDATEUSAGE ('dbname')" to validate
   that the row counts, space used, and unused space is correct. */

/* Specify which database you want to see the Table Sizes for. */
use TWO

/* Creates two temp tables to collect the table size information. */
create table TableSize (
 name char (25),
 rows int,
 reserved char (25),
 data char (25),
 indexsize char (25),
 unused char (25))

create table TableSize2 (
 name char (25),
 rows int,
 reserved int,
 data int,
 indexsize int,
 unused int)

/* Populates the TableSize table with the table size info. */
declare @sp varchar(100)
declare spaceused cursor for select name from sysobjects where type='U'
set nocount on
open spaceused
fetch next from spaceused into @sp
while (@@fetch_status <>-1)
begin

	exec ('insert into TableSize 
               exec sp_spaceused '+  @sp)
	fetch next from spaceused into @sp

end
deallocate spaceused

/* Move the Table info into the second table to remove the KB,
   this way we can arrange the data based off the size of the tables. */
insert into TableSize2 (name,rows,reserved,data,indexsize,unused)
select name,rows,cast(replace(reserved,'KB','') as int),cast(replace(data,'KB','') as int),
  cast(replace(indexsize,'KB','') as int),cast(replace(unused,'KB','') as int)
  from TableSize
set nocount off

/* Display the tables by the reserved size in descending order. */
select * from TableSize2 order by reserved desc

/* Drop the two temp tables after you have saved the results from the above script. */
drop table TableSize
drop table TableSize2
