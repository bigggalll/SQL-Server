declare @sp varchar(100)
use DYNAMICS
declare spaceused CURSOR for select name from sysobjects where type='U'
set nocount on
OPEN spaceused
FETCH NEXT from spaceused into @sp

while (@@FETCH_STATUS <>-1)
begin

	exec ("sp_spaceused "+  @sp)
	FETCH NEXT from spaceused into @sp

end

DEALLOCATE spaceused