/* Cursor to enable all triggers in a database */

declare @TRIGGER  char (255)

declare Enable_cursor CURSOR for select 'alter table '+x.name+' enable trigger '+rtrim(o.name)
	 from sysobjects o, sysobjects x
		where o.type = 'TR' and 
		      o.parent_obj = x.id

set nocount on
OPEN Enable_cursor
FETCH NEXT FROM Enable_cursor INTO @TRIGGER
WHILE (@@FETCH_STATUS <> -1)
begin
	print @TRIGGER
	exec (@TRIGGER)
	FETCH NEXT FROM Enable_cursor INTO @TRIGGER
end
DEALLOCATE Enable_cursor
set nocount off
