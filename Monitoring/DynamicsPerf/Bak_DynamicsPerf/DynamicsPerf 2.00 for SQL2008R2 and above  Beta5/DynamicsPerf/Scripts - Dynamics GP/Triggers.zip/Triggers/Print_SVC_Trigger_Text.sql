declare @NAME varchar(50)
declare @TEXT varchar(8000)
declare TriggerText insensitive cursor for 
select name from sysobjects where type = 'TR' and parent_obj in
  (select id from sysobjects where type = 'U' and name in
    ('SVC00200','SVC00203','SVC00211','SVC00710','SVC05210','SVC05601','SVC06100','SVC06101'))
open TriggerText
set nocount on
fetch next from TriggerText into @NAME
while (@@fetch_status <> -1) begin
  if (@@fetch_status <> -2) begin
    select @TEXT = 'sp_helptext ' + @NAME
  end
  exec (@TEXT)
  fetch next from TriggerText into @NAME
end
deallocate TriggerText
set nocount off
