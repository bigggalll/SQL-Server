/* Cursor to disable the triggers on just the tables you list.
   Make sure you replace the TableName with the tables you want to disable the triggers. */

declare @TRIGGER  char (255)

declare Disable_cursor CURSOR for select 'alter table '+x.name+' disable trigger '+rtrim(o.name)
	 from sysobjects o join sysobjects x on o.parent_obj = x.id
		where o.type = 'TR' and x.name in ('TableName','TableName')

set nocount on
OPEN Disable_cursor
FETCH NEXT FROM Disable_cursor INTO @TRIGGER
WHILE (@@FETCH_STATUS <> -1)
begin
	print @TRIGGER
	exec (@TRIGGER)
	FETCH NEXT FROM Disable_cursor INTO @TRIGGER
end
DEALLOCATE Disable_cursor
set nocount off
