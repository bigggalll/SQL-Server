/* Cursor to enable the triggers on just the tables you list. 
   Make sure you replace the TableName with the tables you want to enable the triggers. */

declare @TRIGGER  char (255)

declare Enable_cursor CURSOR for select 'alter table '+x.name+' enable trigger '+rtrim(o.name)
	 from sysobjects o join sysobjects x on o.parent_obj = x.id
		where o.type = 'TR' and x.name in ('TableName','TableName')

set nocount on
OPEN Enable_cursor
FETCH NEXT FROM Enable_cursor INTO @TRIGGER
WHILE (@@FETCH_STATUS <> -1)
begin
	print @TRIGGER
	exec (@TRIGGER)
	FETCH NEXT FROM Enable_cursor INTO @TRIGGER
end
DEALLOCATE Enable_cursor
set nocount off
