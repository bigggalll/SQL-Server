/* Cursor to disable all triggers in a database */

declare @TRIGGER  char (255)

declare Disable_cursor CURSOR for select 'alter table '+x.name+' disable trigger '+rtrim(o.name)
	 from sysobjects o, sysobjects x
		where o.type = 'TR' and 
		      o.parent_obj = x.id

set nocount on
OPEN Disable_cursor
FETCH NEXT FROM Disable_cursor INTO @TRIGGER
WHILE (@@FETCH_STATUS <> -1)
begin
	print @TRIGGER
	exec (@TRIGGER)
	FETCH NEXT FROM Disable_cursor INTO @TRIGGER
end
DEALLOCATE Disable_cursor
set nocount off
