declare @NAME varchar(50)
declare @TEXT varchar(8000)
declare TriggerText insensitive cursor for 
select name from sysobjects where xtype='TR' and parent_obj in
  (select id from sysobjects where xtype='U' and name in ('SOP10100','SOP10200'))
open TriggerText
set nocount on
fetch next from TriggerText into @NAME
while (@@fetch_status <> -1)
begin
	if (@@fetch_status <> -2)
	begin
		select @TEXT = 'sp_helptext ' + @NAME
	end
	exec (@TEXT)
	fetch next from TriggerText into @NAME
end
deallocate TriggerText
set nocount off
