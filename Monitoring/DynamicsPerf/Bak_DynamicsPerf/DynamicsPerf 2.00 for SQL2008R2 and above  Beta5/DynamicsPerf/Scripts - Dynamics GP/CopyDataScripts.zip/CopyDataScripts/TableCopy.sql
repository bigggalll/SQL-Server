declare @cStatement varchar(255)	/* Value from the t_cursor */
declare @FullStatement varchar (8000)
declare @ColumnCount int		/* Counter for # columns on current line */
declare @NumColumnBlocks int 		/* Total # of columns to print per line */
declare @FirstTime int			/* First time through print loop */
declare @TableName char(255)		/* Table whose columns will be listed */
declare @PrintString char(255)		/* Used to build up the print line */

set nocount on
select @TableName = 'PM00202'		/* Name of table */
select @NumColumnBlocks = 8		/* How many columns to have per line */

select @FullStatement = 'insert into NEWDB..' + rtrim(@TableName) + ' ('

declare T_cursor cursor for
  select c.name from syscolumns c, sysobjects o
    where o.name = @TableName  and o.id = c.id

select @ColumnCount = 0
select @PrintString = ''
select @FirstTime = 1

set nocount on

open T_cursor
fetch next from T_cursor into @cStatement 
while (@@fetch_status <> -1) begin
  if (@cStatement <> 'DEX_ROW_ID') begin
    if (@FirstTime = 1)
      begin
      select @PrintString = '  ' + @cStatement
      select @FirstTime = 0
      end
    else
      begin
      select @PrintString = rtrim(@PrintString) + ','
      if (@ColumnCount = @NumColumnBlocks)
        begin
        select @FullStatement=rtrim(@FullStatement) + '
' + rtrim(@PrintString)
        select @ColumnCount = 0
        select @PrintString = ''
        end
      if (@ColumnCount = 0) select @PrintString = '  ' + @cStatement
      else  select @PrintString = rtrim(@PrintString) + @cStatement
      end
    select @ColumnCount = @ColumnCount + 1
  end
  fetch next from T_cursor into @cStatement 
  end
deallocate T_cursor
/* Print the remaining columns. */
select @FullStatement=rtrim(@FullStatement) + '
' + rtrim(@PrintString) + ')
select '

declare T_cursor cursor for
  select c.name from syscolumns c, sysobjects o
    where o.name = @TableName  and o.id = c.id

select @ColumnCount = 0
select @PrintString = ''
select @FirstTime = 1

open T_cursor
fetch next from T_cursor into @cStatement 
while (@@fetch_status <> -1) begin
  if (@cStatement <> 'DEX_ROW_ID') begin
    if (@FirstTime = 1) begin
      select @PrintString = '  ' + @cStatement
      select @FirstTime = 0
      end
    else
      begin
      select @PrintString = rtrim(@PrintString) + ','
      if (@ColumnCount = @NumColumnBlocks)
        begin
        select @FullStatement=rtrim(@FullStatement) + '
' + rtrim(@PrintString)
        select @ColumnCount = 0
        select @PrintString = ''
        end
      if (@ColumnCount = 0) select @PrintString = '  ' + @cStatement
      else  select @PrintString = rtrim(@PrintString) + @cStatement
      end
    select @ColumnCount = @ColumnCount + 1
    end
  fetch next from T_cursor into @cStatement 
  end
deallocate T_cursor
select @FullStatement=rtrim(@FullStatement) + '
' + rtrim(@PrintString)+'
from OLDDB..'+rtrim(@TableName)
set nocount off
print rtrim(@FullStatement)
