/*  PM Aging Report in Excel.  The indexes and/or view might need to be modified
    to have the correct Aging Buckets. */

/*  First create two new indexes on the PM00200 and PM20000 tables to help
    increase the performance of the PMOpenInvoiceAmounts view. */

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'PMAGEPM20000' and t2.id = t1.id
    and t1.id = Object_id('PM20000') and t1.type = 'U')
  drop index PM20000.PMAGEPM20000
go
create index PMAGEPM20000 on PM20000 (VCHRNMBR,DOCNUMBR,DOCTYPE,VENDORID,DOCDATE,DUEDATE,CURTRXAM,VOIDED)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'PMAGEPM00200' and t2.id = t1.id
    and t1.id = Object_id('PM00200') and t1.type = 'U')
  drop index PM00200.PMAGEPM00200
go
create index PMAGEPM00200 on PM00200 (VENDORID,VENDNAME,VNDCLSID)
go


/*  The PMOpenRecords view will pull together all the Open records either from
    a single company or from multiple company databases.*/

if exists (select * from dbo.sysobjects
  where id = object_id('dbo.PMOpenRecords') and sysstat & 0xf = 2)
drop view dbo.PMOpenRecords
go
create view PMOpenRecords as
select 'TWO' as DBNAME,a.VCHRNMBR,a.DOCTYPE,a.DOCNUMBR,a.VENDORID,
       b.VENDNAME,b.VNDCLSID,a.CURTRXAM,a.DOCDATE,a.DUEDATE
from TWO..PM20000 a
  left outer join TWO..PM00200 b on a.VENDORID=b.VENDORID
where a.DOCTYPE<=3 and a.CURTRXAM<>0.0000 and a.VOIDED=0
union all
select 'TWO' as DBNAME,a.VCHRNMBR,a.DOCTYPE,a.DOCNUMBR,a.VENDORID,
       b.VENDNAME,b.VNDCLSID,(a.CURTRXAM * -1),a.DOCDATE,a.DUEDATE
from TWO..PM20000 a
  left outer join TWO..PM00200 b on a.VENDORID=b.VENDORID
where a.DOCTYPE>=4 and a.CURTRXAM<>0.0000 and a.VOIDED=0
union all
select 'TEST' as DBNAME,a.VCHRNMBR,a.DOCTYPE,a.DOCNUMBR,a.VENDORID,
       b.VENDNAME,b.VNDCLSID,a.CURTRXAM,a.DOCDATE,a.DUEDATE
from TEST..PM20000 a
  left outer join TEST..PM00200 b on a.VENDORID=b.VENDORID
where a.DOCTYPE<=3 and a.CURTRXAM<>0.0000 and a.VOIDED=0
union all
select 'TEST' as DBNAME,a.VCHRNMBR,a.DOCTYPE,a.DOCNUMBR,a.VENDORID,
       b.VENDNAME,b.VNDCLSID,(a.CURTRXAM * -1),a.DOCDATE,a.DUEDATE
from TEST..PM20000 a
  left outer join TEST..PM00200 b on a.VENDORID=b.VENDORID
where a.DOCTYPE>=4 and a.CURTRXAM<>0.0000 and a.VOIDED=0
GO
grant select on dbo.PMOpenRecords to DYNGRP
GO


/* The PMAgingAmounts view will add the DAYSAGED and AGEBUCKET fields.  This
   view can be setup to match the Great Plains Aging Periods and to Age by 
   either the Document Date or Due Date. */

if exists (select * from dbo.sysobjects
  where id = object_id('dbo.PMAgingAmounts') and sysstat & 0xf = 2)
drop view dbo.PMAgingAmounts
go
create view PMAgingAmounts as
select DBNAME,VCHRNMBR,DOCTYPE,DOCNUMBR,VENDORID,
       VENDNAME,VNDCLSID,CURTRXAM,DOCDATE,DUEDATE,
  cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
  cast(datepart(mm,getdate())as char)+'-'+
  cast(datepart(dd,getdate())as char)) as datetime)-DOCDATE) as int) as 'DAYSAGED',
  'AGEBUCKET' = case
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-DOCDATE) as int)
       <= 30 then '0 to 30 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-DOCDATE) as int)
      between 31 and 60 then '31 to 60 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-DOCDATE) as int)
      between 61 and 90 then '61 to 90 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-DOCDATE) as int)
      between 91 and 120 then '91 to 120 Days'
    else 'Over 121 Days'
  end
from PMOpenRecords
GO
grant select on dbo.PMAgingAmounts to DYNGRP
GO
