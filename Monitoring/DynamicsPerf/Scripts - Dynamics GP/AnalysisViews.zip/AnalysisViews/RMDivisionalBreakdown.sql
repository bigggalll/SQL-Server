/*  Divisional Breakdown of Open Receivable Invoices per GL Account or
    GL Account Segment.  The indexes and/or view might need to be modified
    to have the correct Aging Buckets and/or GL segments. */

/*  First create a few new indexes to help increase the performance. */

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'AGEGL00105' and t2.id = t1.id
    and t1.id = Object_id('GL00105') and t1.type = 'U')
  drop index GL00105.AGEGL00105
go
create index AGEGL00105 on GL00105 (ACTINDX,ACTNUMST,ACTNUMBR_1,ACTNUMBR_2,ACTNUMBR_3)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'RMAGERM20101' and t2.id = t1.id
    and t1.id = Object_id('RM20101') and t1.type = 'U')
  drop index RM20101.RMAGERM20101
go
create index RMAGERM20101 on RM20101 (DOCNUMBR,CUSTNMBR,RMDTYPAL,DOCDATE,DUEDATE,CURTRXAM,VOIDSTTS)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'RMAGERM00101' and t2.id = t1.id
    and t1.id = Object_id('RM00101') and t1.type = 'U')
  drop index RM00101.RMAGERM00101
go
create index RMAGERM00101 on RM00101 (CUSTNMBR,CUSTNAME,CUSTCLAS)
go


/*  Create the view that will break out the Open Receivable Invoices
    to the correct Aging Buckets, GL Sales Account, and
    GL Sales Account segments.  This view can be used with Excel
    to create Pivot Tables on the data and summaries the Open Invoices. */

if exists (select * from dbo.sysobjects
  where id = object_id('dbo.RMOpenInvoiceAmounts') and sysstat & 0xf = 2)
drop view dbo.RMOpenInvoiceAmounts
go
create view RMOpenInvoiceAmounts as
select a.DOCNUMBR,a.CUSTNMBR,d.CUSTNAME,d.CUSTCLAS,
    round(b.CRDTAMNT*(a.CURTRXAM/a.DOCAMNT),2) as CURTRXAM,a.DOCDATE,a.DUEDATE,
  cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
  cast(datepart(mm,getdate())as char)+'-'+
  cast(datepart(dd,getdate())as char)) as datetime)-a.DOCDATE) as int) as 'DAYSAGED',
  'AGEBUCKET' = case
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-a.DOCDATE) as int)
       between 0 and 30 then '0 to 30 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-a.DOCDATE) as int)
      between 31 and 60 then '31 to 60 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-a.DOCDATE) as int)
      between 61 and 90 then '61 to 90 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-a.DOCDATE) as int)
      between 91 and 120 then '91 to 120 Days'
    else 'Over 121 Days'
  end,
  c.ACTNUMST,c.ACTNUMBR_1,c.ACTNUMBR_2,c.ACTNUMBR_3
from RM20101 a
  left outer join RM10101 b on a.DOCNUMBR=b.DOCNUMBR and a.RMDTYPAL=b.RMDTYPAL
  left outer join GL00105 c on b.DSTINDX=c.ACTINDX
  left outer join RM00101 d on a.CUSTNMBR=d.CUSTNMBR
where a.RMDTYPAL=1 and a.CURTRXAM<>0.0000 and a.VOIDSTTS=0
  and b.DISTTYPE=9 and DOCDATE<=getdate()
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.RMOpenInvoiceAmounts TO DYNGRP
GO
