if exists (select * from dbo.sysobjects
  where id = object_id('dbo.PMAppliedInfo') and sysstat & 0xf = 2)
drop view dbo.PMAppliedInfo 
GO
create view dbo.PMAppliedInfo as
select a.VENDORID,b.VENDNAME,b.VNDCLSID,a.APTVCHNM,a.APTODCTY,
  a.APTODCNM,a.APPLDAMT,a.VCHRNMBR,a.DOCTYPE,a.APFRDCNM,
  datepart(year,a.DATE1) as 'Year',datename(month,a.DATE1) as 'Month',
  datepart(wk,a.DATE1) as 'Week'
from PM30300 a
  left outer join PM00200 b on a.VENDORID=b.VENDORID
where DOCTYPE=6
union
select a.VENDORID,b.VENDNAME,b.VNDCLSID,a.APTVCHNM,a.APTODCTY,
  a.APTODCNM,a.APPLDAMT,a.VCHRNMBR,a.DOCTYPE,a.APFRDCNM,
  datepart(year,a.DATE1) as 'Year',datename(month,a.DATE1) as 'Month',
  datepart(wk,a.DATE1) as 'Week'
from PM10200 a
  left outer join PM00200 b on a.VENDORID=b.VENDORID
where DOCTYPE=6
GO
grant select on dbo.PMAppliedInfo to DYNGRP
GO
