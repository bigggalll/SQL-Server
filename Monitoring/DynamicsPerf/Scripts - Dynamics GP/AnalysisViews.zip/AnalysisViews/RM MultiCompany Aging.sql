/*  RM Aging Report in Excel.  The indexes and/or view might need to be modified
    to have the correct Aging Buckets. */

/*  First create two new indexes on the RM00101 and RM20101 tables to help
    increase the performance of the RMOpenInvoiceAmounts view. */

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'RMAGERM20101' and t2.id = t1.id
    and t1.id = Object_id('RM20101') and t1.type = 'U')
  drop index RM20101.RMAGERM20101
go
create index RMAGERM20101 on RM20101 (DOCNUMBR,CUSTNMBR,RMDTYPAL,DOCDATE,DUEDATE,CURTRXAM,VOIDSTTS)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'RMAGERM00101' and t2.id = t1.id
    and t1.id = Object_id('RM00101') and t1.type = 'U')
  drop index RM00101.RMAGERM00101
go
create index RMAGERM00101 on RM00101 (CUSTNMBR,CUSTNAME,CUSTCLAS)
go


/*  The RMOpenRecords view will pull together all the Open records either from
    a single company or from multiple company databases.*/

if exists (select * from dbo.sysobjects
  where id = object_id('dbo.RMOpenRecords') and sysstat & 0xf = 2)
drop view dbo.RMOpenRecords
go
create view RMOpenRecords as
select 'TWO' as DBNAME,a.DOCNUMBR,a.RMDTYPAL,a.CUSTNMBR,
       b.CUSTNAME,b.CUSTCLAS,a.CURTRXAM,a.DOCDATE,a.DUEDATE
from TWO..RM20101 a
  left outer join TWO..RM00101 b on a.CUSTNMBR=b.CUSTNMBR
where a.RMDTYPAL<=3 and a.CURTRXAM<>0.0000 and a.VOIDSTTS=0
union all
select 'TWO' as DBNAME,a.DOCNUMBR,a.RMDTYPAL,a.CUSTNMBR,
       b.CUSTNAME,b.CUSTCLAS,(a.CURTRXAM * -1),a.DOCDATE,a.DUEDATE
from TWO..RM20101 a
  left outer join TWO..RM00101 b on a.CUSTNMBR=b.CUSTNMBR
where a.RMDTYPAL>=4 and a.CURTRXAM<>0.0000 and a.VOIDSTTS=0
union all
select 'TEST' as DBNAME,a.DOCNUMBR,a.RMDTYPAL,a.CUSTNMBR,
       b.CUSTNAME,b.CUSTCLAS,a.CURTRXAM,a.DOCDATE,a.DUEDATE
from TWO..RM20101 a
  left outer join TWO..RM00101 b on a.CUSTNMBR=b.CUSTNMBR
where a.RMDTYPAL<=3 and a.CURTRXAM<>0.0000 and a.VOIDSTTS=0
union all
select 'TEST' as DBNAME,a.DOCNUMBR,a.RMDTYPAL,a.CUSTNMBR,
       b.CUSTNAME,b.CUSTCLAS,(a.CURTRXAM * -1),a.DOCDATE,a.DUEDATE
from TWO..RM20101 a
  left outer join TWO..RM00101 b on a.CUSTNMBR=b.CUSTNMBR
where a.RMDTYPAL>=4 and a.CURTRXAM<>0.0000 and a.VOIDSTTS=0
GO
grant select on dbo.RMOpenRecords to DYNGRP
GO


/* The RMAgingAmounts view will add the DAYSAGED and AGEBUCKET fields.  This
   view can be setup to match the Great Plains Aging Periods and to Age by 
   either the Document Date or Due Date. */

if exists (select * from dbo.sysobjects
  where id = object_id('dbo.RMAgingAmounts') and sysstat & 0xf = 2)
drop view dbo.RMAgingAmounts
go
create view RMAgingAmounts as
select DBNAME,DOCNUMBR,RMDTYPAL,CUSTNMBR,CUSTNAME,CUSTCLAS,CURTRXAM,DOCDATE,DUEDATE,
  cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
  cast(datepart(mm,getdate())as char)+'-'+
  cast(datepart(dd,getdate())as char)) as datetime)-DOCDATE) as int) as 'DAYSAGED',
  'AGEBUCKET' = case
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-DOCDATE) as int)
       between 0 and 30 then '0 to 30 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-DOCDATE) as int)
      between 31 and 60 then '31 to 60 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-DOCDATE) as int)
      between 61 and 90 then '61 to 90 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-DOCDATE) as int)
      between 91 and 120 then '91 to 120 Days'
    else 'Over 121 Days'
  end
from RMOpenRecords
GO
grant select on dbo.RMAgingAmounts to DYNGRP
GO
