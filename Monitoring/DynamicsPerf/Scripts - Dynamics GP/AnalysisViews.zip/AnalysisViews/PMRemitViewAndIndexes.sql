if exists (select * from dbo.sysobjects
  where id = object_id('dbo.PMCheckRemit')
    and OBJECTPROPERTY(id, 'IsView') = 1)
drop view dbo.PMCheckRemit
go
create view dbo.PMCheckRemit as
select a.VENDORID,b.VENDNAME,a.VCHRNMBR,a.DOCTYPE,a.DOCNUMBR as CHECKNUM,a.DOCDATE as CHECKDATE,a.CHEKBKID,
  '' as INVCMNUM,'' as INVCMDATE,'' as BACHNUMB,a.DOCAMNT,a.DISTKNAM,a.WROFAMNT
  from PM30200 a
    join PM00200 b on a.VENDORID=b.VENDORID
  where a.DOCTYPE = 6
union
select a.VENDORID,d.VENDNAME,a.VCHRNMBR,a.DOCTYPE,c.DOCNUMBR as CHECKNUM,c.DOCDATE as CHECKDATE,c.CHEKBKID,
  a.DOCNUMBR as INVCMNUM,a.DOCDATE as INVCMDATE,a.BACHNUMB,a.DOCAMNT,a.DISTKNAM,a.WROFAMNT
  from PM30200 a
    join PM30300 b on a.VCHRNMBR=b.APTVCHNM and a.DOCTYPE=b.APTODCTY
    join PM30200 c on b.VCHRNMBR=c.VCHRNMBR and b.DOCTYPE=c.DOCTYPE
    join PM00200 d on a.VENDORID=d.VENDORID
  where a.DOCTYPE = 1 and b.DOCTYPE = 6
union
select a.VENDORID,d.VENDNAME,a.VCHRNMBR,a.DOCTYPE,c.DOCNUMBR as CHECKNUM,c.DOCDATE as CHECKDATE,c.CHEKBKID,
  a.DOCNUMBR as INVCMNUM,a.DOCDATE as INVCMDATE,a.BACHNUMB,a.DOCAMNT,a.DISTKNAM,a.WROFAMNT
  from PM20000 a
    join PM30300 b on a.VCHRNMBR=b.APTVCHNM and a.DOCTYPE=b.APTODCTY
    join PM30200 c on b.VCHRNMBR=c.VCHRNMBR and b.DOCTYPE=c.DOCTYPE
    join PM00200 d on a.VENDORID=d.VENDORID
  where a.DOCTYPE = 1 and b.DOCTYPE = 6
union
select a.VENDORID,e.VENDNAME,a.VCHRNMBR,a.DOCTYPE,d.DOCNUMBR as CHECKNUM,d.DOCDATE as CHECKDATE,d.CHEKBKID,
  a.DOCNUMBR as INVCMNUM,a.DOCDATE as INVCMDATE,a.BACHNUMB,a.DOCAMNT*-1,a.DISTKNAM,a.WROFAMNT
  from PM30200 a
    join PM30300 b on a.VCHRNMBR=b.VCHRNMBR and a.DOCTYPE=b.DOCTYPE
    join PM30300 c on b.APTVCHNM=c.APTVCHNM and b.APTODCTY=c.APTODCTY
    join PM30200 d on c.VCHRNMBR=d.VCHRNMBR and c.DOCTYPE=d.DOCTYPE
    join PM00200 e on a.VENDORID=e.VENDORID
  where a.DOCTYPE = 5 and c.DOCTYPE=6
union
select a.VENDORID,e.VENDNAME,a.VCHRNMBR,a.DOCTYPE,d.DOCNUMBR as CHECKNUM,d.DOCDATE as CHECKDATE,d.CHEKBKID,
  a.DOCNUMBR as INVCMNUM,a.DOCDATE as INVCMDATE,a.BACHNUMB,a.DOCAMNT*-1,a.DISTKNAM,a.WROFAMNT
  from PM20000 a
    join PM30300 b on a.VCHRNMBR=b.VCHRNMBR and a.DOCTYPE=b.DOCTYPE
    join PM30300 c on b.APTVCHNM=c.APTVCHNM and b.APTODCTY=c.APTODCTY
    join PM30200 d on c.VCHRNMBR=d.VCHRNMBR and c.DOCTYPE=d.DOCTYPE
    join PM00200 e on a.VENDORID=e.VENDORID
  where a.DOCTYPE = 5 and c.DOCTYPE=6
go
grant select on dbo.PMCheckRemit to DYNGRP
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
where t2.name = 'PMRemitPM00200' and t2.id = t1.id
  and t1.id = Object_id('PM00200') and t1.type = 'U')
drop index PM00200.PMRemitPM00200
go
create index PMRemitPM00200 on PM00200 (VENDORID, VENDNAME)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
where t2.name = 'PMRemitPM30200' and t2.id = t1.id
  and t1.id = Object_id('PM30200') and t1.type = 'U')
drop index PM30200.PMRemitPM30200
go
create index PMRemitPM30200 on PM30200
  (VCHRNMBR,DOCTYPE,VENDORID,DOCNUMBR,DOCDATE,CHEKBKID,BACHNUMB,DOCAMNT,DISTKNAM,WROFAMNT)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
where t2.name = 'PMRemitPM20000' and t2.id = t1.id
  and t1.id = Object_id('PM20000') and t1.type = 'U')
drop index PM20000.PMRemitPM20000
go
create index PMRemitPM20000 on PM20000
  (VCHRNMBR,DOCTYPE,VENDORID,DOCNUMBR,DOCDATE,CHEKBKID,BACHNUMB,DOCAMNT,DISTKNAM,WROFAMNT)
go
