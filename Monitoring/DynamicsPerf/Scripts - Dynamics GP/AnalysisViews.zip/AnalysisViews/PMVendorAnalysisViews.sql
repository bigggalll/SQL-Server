/*  The First View (PMAppliedInfo) will return all distinct Applied Records from the
    Work, Open, and History tables.  This will be used in the Second view
    (VendorAnalysisInfo) so we can summaries the amounts for each month of each year.
    Then this can be used in Excel to create a Vendor Analysis Pivot Table. */

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'PMAGEPM30300' and t2.id = t1.id
    and t1.id = Object_id('PM30300') and t1.type = 'U')
  drop index PM30300.PMAGEPM30300
go
create index PMAGEPM30300 on PM30300
  (VENDORID,APTVCHNM,APTODCTY,APTODCNM,APPLDAMT,VCHRNMBR,DOCTYPE,APFRDCNM,DATE1)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'PMAGEPM10200' and t2.id = t1.id
    and t1.id = Object_id('PM10200') and t1.type = 'U')
  drop index PM10200.PMAGEPM10200
go
create index PMAGEPM10200 on PM10200
  (VENDORID,APTVCHNM,APTODCTY,APTODCNM,APPLDAMT,VCHRNMBR,DOCTYPE,APFRDCNM,DATE1)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'PMAGEPM00200' and t2.id = t1.id
    and t1.id = Object_id('PM00200') and t1.type = 'U')
  drop index PM00200.PMAGEPM00200
go
create index PMAGEPM00200 on PM00200 (VENDORID,VENDNAME,VNDCLSID)
go

if exists (select * from dbo.sysobjects
  where id = object_id('dbo.PMAppliedInfo') and sysstat & 0xf = 2)
drop view dbo.PMAppliedInfo 
GO
create view dbo.PMAppliedInfo as
select a.VENDORID,b.VENDNAME,b.VNDCLSID,a.APTVCHNM,a.APTODCTY,
  a.APTODCNM,a.APPLDAMT,a.VCHRNMBR,a.DOCTYPE,a.APFRDCNM,
  datepart(year,a.DATE1) as 'Year',datename(month,a.DATE1) as 'Month',
  datepart(wk,a.DATE1) as 'Week'
from PM30300 a
  left outer join PM00200 b on a.VENDORID=b.VENDORID
where DOCTYPE=6
union
select a.VENDORID,b.VENDNAME,b.VNDCLSID,a.APTVCHNM,a.APTODCTY,
  a.APTODCNM,a.APPLDAMT,a.VCHRNMBR,a.DOCTYPE,a.APFRDCNM,
  datepart(year,a.DATE1) as 'Year',datename(month,a.DATE1) as 'Month',
  datepart(wk,a.DATE1) as 'Week'
from PM10200 a
  left outer join PM00200 b on a.VENDORID=b.VENDORID
where DOCTYPE=6
GO
grant select on dbo.PMAppliedInfo to DYNGRP
GO
