/*  The First View (RMAppliedInfo) will return all distinct Applied Records from the
    Work, Open, and History tables.  This will be used in the Second view
    (CustomerAnalysisInfo) so we can summaries the amounts for each month of each year.
    Then this can be used in Excel to create a Customer Analysis Pivot Table. */

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'RMAGERM30201' and t2.id = t1.id
    and t1.id = Object_id('RM30201') and t1.type = 'U')
  drop index RM30201.RMAGERM30201
go
create index RMAGERM30201 on RM30201 (APFRDCTY,APFRDCNM,CUSTNMBR,APTODCNM,APTODCTY,APPTOAMT,APFRDCDT)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'RMAGERM20201' and t2.id = t1.id
    and t1.id = Object_id('RM20201') and t1.type = 'U')
  drop index RM20201.RMAGERM20201
go
create index RMAGERM20201 on RM20201 (APFRDCTY,APFRDCNM,CUSTNMBR,APTODCNM,APTODCTY,APPTOAMT,APFRDCDT)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'RMAGERM00101' and t2.id = t1.id
    and t1.id = Object_id('RM00101') and t1.type = 'U')
  drop index RM00101.RMAGERM00101
go
create index RMAGERM00101 on RM00101 (CUSTNMBR,CUSTNAME,CUSTCLAS)
go

if exists (select * from dbo.sysobjects where id = object_id('dbo.RMAppliedInfo')
  and sysstat & 0xf = 2)
drop view dbo.RMAppliedInfo 
GO
create view dbo.RMAppliedInfo as
select a.CUSTNMBR,b.CUSTNAME,b.CUSTCLAS,a.APTODCNM,a.APTODCTY,a.APPTOAMT,a.APFRDCNM,a.APFRDCTY,
       datepart(year,a.APFRDCDT) as 'YEAR1',datename(month,a.APFRDCDT) as 'MONTH1'
from RM30201 a
  left outer join RM00101 b on a.CUSTNMBR=b.CUSTNMBR
where a.APFRDCTY=9
union
select a.CUSTNMBR,b.CUSTNAME,b.CUSTCLAS,a.APTODCNM,a.APTODCTY,a.APPTOAMT,a.APFRDCNM,a.APFRDCTY,
       datepart(year,a.APFRDCDT) as 'YEAR1',datename(month,a.APFRDCDT) as 'MONTH1'
from RM20201 a
  left outer join RM00101 b on a.CUSTNMBR=b.CUSTNMBR
where a.APFRDCTY=9
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON dbo.RMAppliedInfo TO DYNGRP
GO
