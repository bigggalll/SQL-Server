/*  Divisional Breakdown of Open Payables Invoices per GL Account or
    GL Account Segment.  The indexes and/or view might need to be modified
    to have the correct Aging Buckets and/or GL segments. */

/*  First create two new indexes on the GL00105 and PM20000 tables to help
    increase the performance of the PMOpenInvoiceAmounts view. */

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'AGEGL00105' and t2.id = t1.id
    and t1.id = Object_id('GL00105') and t1.type = 'U')
  drop index GL00105.AGEGL00105
go
create index AGEGL00105 on GL00105 (ACTINDX,ACTNUMST,ACTNUMBR_1,ACTNUMBR_2,ACTNUMBR_3,ACTNUMBR_4)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'PMAGEPM20000' and t2.id = t1.id
    and t1.id = Object_id('PM20000') and t1.type = 'U')
  drop index PM20000.PMAGEPM20000
go
create index PMAGEPM20000 on PM20000 (VCHRNMBR,VENDORID,DOCTYPE,CURTRXAM,VOIDED,DOCNUMBR,DOCDATE,DUEDATE,DOCAMNT)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'PMAGEPM00200' and t2.id = t1.id
    and t1.id = Object_id('PM00200') and t1.type = 'U')
  drop index PM00200.PMAGEPM00200
go
create index PMAGEPM00200 on PM00200 (VENDORID,VENDNAME,VNDCLSID,STATE)
go

if exists (select * from dbo.sysobjects t1, dbo.sysindexes t2
  where t2.name = 'PMAGEPM10100' and t2.id = t1.id
    and t1.id = Object_id('PM10100') and t1.type = 'U')
  drop index PM10100.PMAGEPM10100
go
create index PMAGEPM10100 on PM10100 (VCHRNMBR,DSTINDX,CNTRLTYP,DISTTYPE,DEBITAMT)
go


/*  Create the view that will break out the Open Payables Invoices
    to the correct Aging Buckets, GL Purchasing Account, and
    GL Purchasing Account segments.  This view can be used with Excel
    to create Pivot Tables on the data and summaries the Open Invoices. */

if exists (select * from dbo.sysobjects
  where id = object_id('dbo.PMOpenInvoiceAmounts') and sysstat & 0xf = 2)
drop view dbo.PMOpenInvoiceAmounts
go
create view dbo.PMOpenInvoiceAmounts as
select a.VCHRNMBR,a.DOCNUMBR,a.VENDORID,d.VENDNAME,d.VNDCLSID,
    round(b.DEBITAMT*(a.CURTRXAM/a.DOCAMNT),2) as CURTRXAM,a.DOCDATE,a.DUEDATE,
  cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
  cast(datepart(mm,getdate())as char)+'-'+
  cast(datepart(dd,getdate())as char)) as datetime)-a.DOCDATE) as int) as 'DAYSAGED',
  'AGEBUCKET' = case
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-a.DOCDATE) as int)
       <= 30 then '0 to 30 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-a.DOCDATE) as int)
      between 31 and 60 then '31 to 60 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-a.DOCDATE) as int)
      between 61 and 90 then '61 to 90 Days'
    when cast((cast((cast(datepart(yyyy,getdate())as char)+'-'+
         cast(datepart(mm,getdate())as char)+'-'+
         cast(datepart(dd,getdate())as char)) as datetime)-a.DOCDATE) as int)
      between 91 and 120 then '91 to 120 Days'
    else 'Over 121 Days'
  end,
  c.ACTNUMST,c.ACTNUMBR_1,c.ACTNUMBR_2,c.ACTNUMBR_3
from PM20000 a
  left outer join PM10100 b on a.VCHRNMBR=b.VCHRNMBR
  left outer join GL00105 c on b.DSTINDX=c.ACTINDX
  left outer join PM00200 d on a.VENDORID=d.VENDORID
where a.DOCTYPE=1 and a.CURTRXAM<>0.0000 and a.VOIDED=0
  and b.CNTRLTYP=0 and b.DISTTYPE=6
GO
grant select on dbo.PMOpenInvoiceAmounts to DYNGRP
GO
