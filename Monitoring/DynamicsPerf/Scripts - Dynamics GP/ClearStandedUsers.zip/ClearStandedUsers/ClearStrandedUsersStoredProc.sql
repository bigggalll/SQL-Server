if exists (select * from sysobjects where id = object_id('dbo.ClearStrandedUsers') and sysstat & 0xf = 4)
  drop procedure dbo.ClearStrandedUsers
go

create procedure dbo.ClearStrandedUsers as

delete from DYNAMICS..ACTIVITY where USERID not in (select loginame from master..sysprocesses)
delete from tempdb..DEX_SESSION where session_id not in (select SQLSESID from DYNAMICS..ACTIVITY)
delete from tempdb..DEX_LOCK where session_id not in (select SQLSESID from DYNAMICS..ACTIVITY)
delete from DYNAMICS..SY00800 where USERID not in (select USERID from DYNAMICS..ACTIVITY)
delete from DYNAMICS..SY00801 where USERID not in (select USERID from DYNAMICS..ACTIVITY)

go
grant EXECUTE on dbo.ClearStrandedUsers to DYNGRP
go
