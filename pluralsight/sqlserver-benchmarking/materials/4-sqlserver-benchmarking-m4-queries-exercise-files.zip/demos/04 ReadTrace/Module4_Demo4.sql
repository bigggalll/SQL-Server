/*
	Before running either command, enable SQLCMD mode 
	via the	Query menu
*/

--!!"C:\Program Files\Microsoft Corporation\RMLUtils\ReadTrace.exe" �IC:\Pluralsight\RML\ProdTrace.trc �oC:\Pluralsight\RML\Output �SWIN2008R2PS\SQL2012 �dProdBaseline


--!!"C:\Program Files\Microsoft Corporation\RMLUtils\ReadTrace.exe" �IC:\Pluralsight\RML\TestTrace.trc �oC:\Pluralsight\RML\Output �SWIN2008R2PS\SQL2012 �dTestBenchmark

