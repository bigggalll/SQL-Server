use insert_is_faster_in_2016
go
drop proc insertstempdbfly
go
create proc insertstempdbfly as
begin
create table #watchinsertsfly (col1 int, col2 char(2000) not null)
insert into #watchinsertsfly with (tablock) select * from watchinsertsfly
end
go