USE [master]
GO
DROP DATABASE [insert_is_faster_in_2016_smaller]
GO
CREATE DATABASE [insert_is_faster_in_2016_smaller]
 ON  PRIMARY 
( NAME = N'insert_is_faster_in_2016_smaller', FILENAME = N'C:\temp\insert_is_faster_in_2016_smaller.mdf' , SIZE = 45Gb , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'insert_is_faster_in_2016_smaller_log', FILENAME = N'C:\temp\insert_is_faster_in_2016_smaller_log.ldf' , SIZE = 30Gb , MAXSIZE = UNLIMITED , FILEGROWTH = 65536KB )
GO
alter database insert_is_faster_in_2016_smaller set recovery simple
go