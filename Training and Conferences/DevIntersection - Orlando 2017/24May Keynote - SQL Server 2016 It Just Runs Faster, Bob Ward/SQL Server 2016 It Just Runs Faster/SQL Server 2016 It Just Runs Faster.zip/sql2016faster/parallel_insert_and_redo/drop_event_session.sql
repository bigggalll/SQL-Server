DROP EVENT SESSION [recoverytraces] ON SERVER
go