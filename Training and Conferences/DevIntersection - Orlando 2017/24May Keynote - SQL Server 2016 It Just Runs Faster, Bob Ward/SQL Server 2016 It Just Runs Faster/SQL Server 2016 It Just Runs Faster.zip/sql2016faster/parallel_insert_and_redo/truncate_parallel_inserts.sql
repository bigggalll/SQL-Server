-- NOTE: Be sure the configuration option 'max degree of parallelism' is set to 0
--
use insert_is_faster_in_2016
go
-- STEP 1: Run an INSERT..SELECT with a serial plan by not including TABLOCK hint
-- This is similar to the performance of the query prior to SQL Server 2016
-- First truncate the target table
truncate table parallelinserts
go
