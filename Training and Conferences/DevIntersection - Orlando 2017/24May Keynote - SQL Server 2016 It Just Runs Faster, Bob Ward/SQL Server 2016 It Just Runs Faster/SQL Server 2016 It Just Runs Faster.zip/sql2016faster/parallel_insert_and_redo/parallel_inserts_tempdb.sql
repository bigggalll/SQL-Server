use insert_is_faster_in_2016
go
exec insertstempdbfly
go
