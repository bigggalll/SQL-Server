This folder contains files for demonstrating the features of parallel INSERT..SELECT and parallel redo. This file contains the steps to demonstrate this feature. 
Only run this demonstration on a developerment or test computer runniung SQL Server 2016. 
Never run this on a production server.

All demonstrations were created on a 1 socket 4 core machine with HT enabled. 32Gb RAM with a 1TB PC1NVMe SSD drive using SQL Server 2016 CU1 (13.0.2149.0)
No changes were made to any SQL Server configuration options (aka sp_configure0

Steps to Prepare for the Demo



1. Create the database by using running the create_database.sql file. The db will require ~50Gb of space. Edit the paths according to your installation

2. Run the script fillupthedb.sql to create the table and populate data



Parallel INSERT...SELECT Demo

3. Load up the dmvs.sql script so observe execution of the inserts. Use the Live Query Statistics option in SSMS to see the performance and "actua" plan. Use the perfmon counter Access Methods/Pages Allocated/sec to monitor the throughput of the INSERT..SELECT.
4. Go through the steps as outlined with comments in parallel_inserts.sql to see how inserts can perform serially and using parallelism. Note: for maximum performance if you have restarted SQL Server you should run the first steps in the script twice so the source table can be loaded into cache. Note in perfmon the number of pages allocated/sec and the low CPU with a serial INSERT..SELECT. But notice in the paralle plan how many more pages allocated/sec we can run, how faster the query executes, and how much harder we push the CPU.



Parallel Redo



We will use the database created for parallel INSERT..SELECT to show parallel redo.  You must complete steps 1 and 2 in the section "Steps to Prepare for the Demo" before going through these steps for parallel redo



5. Delete any .XEL files from the path as found in recovery_event_session.sql

6. We will use Extended Evnent to see the details of recovery (aka recovery tracing) so run the script recovery_event_session.sql to create the Extended Event Session. The script is setup to write out the event data to the c:\temp directory so modify the script for the path of your choice.

7. Follow the steps in the parallel_redo.sql script to demonstrate parallel redo for recovery. The script has comments that require you to terminate the SQLSERVR.EXE process as part of the excercise.

8. Run drop_event_session.sql to remove the extended events session. In addition, you can remove the .xel files created for the session in the path specified in recovery_event_session.sql
9. Run drop_database.sql to remove the demonwtration database.
