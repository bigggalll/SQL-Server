USE [master]
GO
DROP DATABASE [insert_is_faster_in_2016]
GO
