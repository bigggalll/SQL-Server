-- NOTE: Be sure the configuration option 'max degree of parallelism' is set to 0
--
use insert_is_faster_in_2016
go
insert into parallelinserts WITH (TABLOCK) select * from watchinsertsfly
go
