1. Run the script in linestringdemo.sql and note the duration
2. Run the restartforsqldemo.cmd file to restart with the apprpopriate trace flag. Chnage the name of the instance depending on your installation.
3. Run the script in linestringdemo.sql again and note the faster time.