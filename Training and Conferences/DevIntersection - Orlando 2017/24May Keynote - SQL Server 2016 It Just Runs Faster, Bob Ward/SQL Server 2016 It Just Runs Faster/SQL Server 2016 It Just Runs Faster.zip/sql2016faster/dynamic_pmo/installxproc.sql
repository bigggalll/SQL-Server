sp_dropextendedproc xp_alloc
go
sp_addextendedproc xp_alloc, 'C:\demos\sql2016faster\dynamic_pmo\xp_alloc.dll'
go