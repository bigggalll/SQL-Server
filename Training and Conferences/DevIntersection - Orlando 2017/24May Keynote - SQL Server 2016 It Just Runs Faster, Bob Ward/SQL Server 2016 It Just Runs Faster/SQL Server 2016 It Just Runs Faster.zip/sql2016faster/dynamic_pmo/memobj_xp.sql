-- These notes will help interpret the output
-- contention_factor is "how hot is the PMO". NULL for any PMO that is not global
-- creation_options:
-- 'Global PMO. Created Partitioned by CPU' = Thread safe PMO that is created by default to be partitioned by CPU
-- 'Global PMO. Created Partitioned by Node' = Thread safe PMO that is created by default to be partitioned by Node. Eligible to be promoted to CPU
-- 'Global PMO. Not created as partitioned' = Thread safe PMO not created to be partitioned. Only partitionable if partition_type = 1 or 2
-- 'Not Global PMO' = Not a thread safe PMO which means only one thread would ever access the PMO. No need to partition.
--
-- partition_type:
-- 1 = 'Partionable on multi-node. Not partitioned' = A global PMO that is partitionable but not created or dynamically partitioned
-- 2 = 'Partitioned by Node. For single Node = Not Partitioned' = For multi-node, check creation options. If not created node partitioning but global, then this means it was dynamically promoted to NODE partitioning
-- For a single node, it means if not created for node partitioning, it is eligible to be promoted to CPU but has not been promoted yet
-- 3 = 'Partioned by CPU' = Check creation options. If not created for CPU partitioning this means it was promoted to CPU in both single and multi-node.
-- 0 = 'Not partitionable' = Global PMO that cannot be partitioned dynamically.
--
declare @iNodes int
select @iNodes = count(*) from sys.dm_os_nodes where node_state_desc not like '%DAC%';

SELECT
contention_factor,
type, pages_in_bytes,
creation_options,
CASE
 WHEN (0x40 = creation_options & 0x40) THEN 'Global PMO. Created Partitioned by CPU.'
 WHEN (0x80 = creation_options & 0x80) THEN 'Global PMO. Created Partitioned by Node'
 WHEN (0x2 = creation_options & 0x2) THEN 'Global PMO. Not created as partitioned'
 ELSE 'Not Global PMO'
END as [Creation Desc],
partition_type,
CASE
 WHEN (1 = partition_type) THEN 'Partionable,  Not partitioned'
 WHEN (2 = partition_type and 1 = @iNodes) THEN 'Partionable,  Not partitioned'
 WHEN (2 = partition_type and 1 <> @iNodes) THEN 'Partitioned by Node.'
 WHEN (3 = partition_type) THEN 'Partioned by CPU'
 WHEN (0 = partition_type) THEN 'Not partionable'
END as [Partition State Desc]
from sys.dm_os_memory_objects
where type = 'MEMOBJ_XP'
go
