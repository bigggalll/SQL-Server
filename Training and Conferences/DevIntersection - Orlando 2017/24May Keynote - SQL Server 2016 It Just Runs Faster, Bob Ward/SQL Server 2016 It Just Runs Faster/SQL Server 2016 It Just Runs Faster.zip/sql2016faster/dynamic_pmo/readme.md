NOTE: Restart SQL Server before running this test. Once we promote a PMO it remains prmoted for the life of the server instance.

1. Execute the DMV query in findglobalpmos.sql and talk about the results
2. Install the xproc by running the script installxproc.sql
3. Setup perfmon by adding the counters SQLServer:Wait Statistics/Thread-safe memory objects/Waits started per second and SQLServer:SQL Statistics/Batch Requests/sec
4. Open up the script memobj_xp.sql to see what the MEMOBJ_XP memory object looks like
5. Open up the script turn_off_and_on_pmo_promotion.sql to turn off and on dynamic pmo promotion
6. From the turn_off_and_on_pmo_promotion.sql, execute the first section to turn off dynamic pmo promotion
7. From the command line, execute the cmd file cmemthread.cmd as follows

cmemthread 8

8. Observe perfmon counters and output of query in memobj_xp.sql.
9. Execute the section in turn_off_and_on_pmo_promotion.sql to turn ON dynamic pmo promotion
10. Observe perfmon counters and output of query in memobj_xp.sql.

Waits should drop to 0
batch reqeusts/sec should increase by around 25% and "smooth" out
The partition_type for sys.dm_os_memory_objects for 'MEMOBJ_XP' should change to a 3