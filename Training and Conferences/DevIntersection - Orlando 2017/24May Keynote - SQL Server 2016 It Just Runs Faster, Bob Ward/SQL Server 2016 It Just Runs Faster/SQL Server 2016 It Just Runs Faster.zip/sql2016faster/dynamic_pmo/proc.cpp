#include "stdafx.h"
#include <process.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <srv.h>

#define XP_NOERROR              0
#define XP_ERROR                1
#define XP_ALLOC_ERROR			50001

#define DEFAULT_ITERATIONS 100
#define DEFAULT_SIZE 1

#ifdef __cplusplus
extern "C" {
#endif

//unsigned int __stdcall CallThread(void *parm);
RETCODE __declspec(dllexport) xp_alloc(SRV_PROC *srvproc);

#ifdef __cplusplus
}
#endif

RETCODE __declspec(dllexport) xp_alloc(SRV_PROC *srvproc)
{
	//int			paramnum = 0;
	//BYTE		paramtype;
	//ULONG		parammaxlen;
	//ULONG		paramlen;
	//BOOL		paramnull;

	int			iterations = DEFAULT_ITERATIONS;
	int			allocsize = DEFAULT_SIZE;
	int			shouldileak = FALSE;
	void		*ptr;
	void		*ptr1;
	void		*ptr2;

	
	// Get number of parameters
	//paramnum = srv_rpcparams( srvproc );

	/* if (paramnum < 2)
	{
		// Send error message and return
		//
		srv_sendmsg(srvproc, SRV_MSG_ERROR, XP_ALLOC_ERROR, SRV_INFO, 1,
			NULL, 0, (DBUSMALLINT)__LINE__,
			"Usage: exec xp_alloc @iterations @allocsize [@leak]>",
			SRV_NULLTERM);
		srv_senddone(srvproc, (SRV_DONE_ERROR | SRV_DONE_MORE), 0, 0);

		return (XP_ERROR);
	} */

		// Get the parameters
	//srv_paraminfo(srvproc, 1, &paramtype, &parammaxlen, &paramlen, (BYTE *)&iterations, &paramnull);
	//srv_paraminfo(srvproc, 2, &paramtype, &parammaxlen, &paramlen, (BYTE *)&allocsize, &paramnull);

	//if (paramnum > 2)
	//	srv_paraminfo(srvproc, 3, &paramtype, &parammaxlen, &paramlen, (BYTE *)&shouldileak, &paramnull);
	
	// Do the allocations
	for (int i = 0; i < iterations; i++)
	{
		ptr = srv_alloc(allocsize);
		if (!ptr)
		{
			srv_sendmsg(srvproc, SRV_MSG_ERROR, XP_ALLOC_ERROR, SRV_INFO, 1,
				NULL, 0, (DBUSMALLINT)__LINE__,
				"Failure allocating memory with srv_alloc",
				SRV_NULLTERM);
			srv_senddone(srvproc, (SRV_DONE_ERROR | SRV_DONE_MORE), 0, 0);

			return (XP_ERROR);
		}

		ptr1 = srv_alloc(allocsize);
		if (!ptr1)
		{
			srv_sendmsg(srvproc, SRV_MSG_ERROR, XP_ALLOC_ERROR, SRV_INFO, 1,
				NULL, 0, (DBUSMALLINT)__LINE__,
				"Failure allocating memory with srv_alloc",
				SRV_NULLTERM);
			srv_senddone(srvproc, (SRV_DONE_ERROR | SRV_DONE_MORE), 0, 0);

			return (XP_ERROR);
		}

		ptr2 = srv_alloc(allocsize);
		if (!ptr2)
		{
			srv_sendmsg(srvproc, SRV_MSG_ERROR, XP_ALLOC_ERROR, SRV_INFO, 1,
				NULL, 0, (DBUSMALLINT)__LINE__,
				"Failure allocating memory with srv_alloc",
				SRV_NULLTERM);
			srv_senddone(srvproc, (SRV_DONE_ERROR | SRV_DONE_MORE), 0, 0);

			return (XP_ERROR);
		}
		if (!shouldileak)
		{
			srv_free(ptr1);
			srv_free(ptr2);
			srv_free(ptr);
		}
		
		// Check for attentions
		//if (srv_got_attention(srvproc))
		//	break;
	}
	
	return XP_NOERROR ;
}

