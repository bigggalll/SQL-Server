-- Turn OFF dynamic pmo promotion
--
dbcc traceon(8074, -1)
go

-- Turn ON dynamic pmo promotion
--
dbcc traceoff(8074, -1)
go