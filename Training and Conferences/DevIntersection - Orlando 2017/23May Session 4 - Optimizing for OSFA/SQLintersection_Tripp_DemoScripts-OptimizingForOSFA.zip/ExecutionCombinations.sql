stored proc
    3 params...

member_no (returns 1 row) --> CL ind seek
lastname
firstname

member_no, ln (returns 1 row) --> CL ind seek
lastname, fn
firstname, mno (returns 1 row) --> CL ind seek

ln, fn, mno (returns 1 row) --> CL ind seek

