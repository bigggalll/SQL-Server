DBCC DROPCLEANBUFFERS;
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

------------------------------------------------
-- Concept: Pricing problem realized...
-- Orders in 2016 should include $1 admin fee

-- (sounds like the airlines, eh? 
-- No, wait - the fee would be much higher! ;-)
------------------------------------------------

DECLARE @StartTime datetime2 = sysdatetime();
SELECT *, [SalesAmount], [SalesAmount] + 1 
FROM [dbo].[factinternetsales]
WHERE [OrderDateKey] >= 20160101
ORDER BY [OrderDateKey];
SELECT 'QueryExecutionTime' = datediff(ms, @StartTime, sysdatetime());
GO  -- 1,196,977 rows

--DECLARE @StartTime datetime2 = sysdatetime();
--UPDATE [dbo].[factinternetsales]
--	SET [SalesAmount] = [SalesAmount] + 1
--WHERE [OrderDateKey] > 20151231;
--SELECT 'QueryExecutionTime' = datediff(ms, @StartTime, sysdatetime());
--GO