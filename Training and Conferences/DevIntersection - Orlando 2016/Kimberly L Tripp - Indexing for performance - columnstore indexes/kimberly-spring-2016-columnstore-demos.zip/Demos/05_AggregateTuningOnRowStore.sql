DBCC DROPCLEANBUFFERS;
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

DECLARE @StartTime datetime2 = sysdatetime();
SELECT [fis].[OrderDateKey]
	, [fis].[ProductKey]
	, SUM([fis].[SalesAmount]) AS 'Total Amount'
	, COUNT(*) AS 'Number of Sales'
FROM [dbo].[factinternetsales] AS [fis]
GROUP BY [fis].[OrderDateKey], [fis].[ProductKey]
--ORDER BY [fis].[OrderDateKey], [fis].[ProductKey]
SELECT 'QueryExecutionTime' = datediff(ms, @StartTime, sysdatetime());
GO

---- Go to another window to do this!
---- In the row-store case, I could tune this query individually to get better performance:
--CREATE INDEX NCIX_PointQuery2 
--ON [dbo].[factinternetsales] ([OrderdateKey], [ProductKey])
--INCLUDE ([SalesAmount])
--GO

--DROP INDEX [dbo].[factinternetsales].[NCIX_PointQuery]