DBCC DROPCLEANBUFFERS;
GO

--SET STATISTICS IO ON;
--GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

DECLARE @StartTime datetime2 = sysdatetime();
SELECT [fis].*
FROM [dbo].[factinternetsales] AS [fis]
WHERE [fis].[OrderdateKey] = 20160419
	AND [fis].[ProductKey] = 565
SELECT 'TimeForAllCols' = datediff(ms, @StartTime, sysdatetime());
GO

-- If you did not do this as part of query #05 then, go to another window to tune for
-- the row-store case. Use this index to tune this query individually to get better 
-- performance:
--CREATE INDEX NCIX_PointQuery2 
--ON [dbo].[factinternetsales] ([OrderdateKey], [ProductKey])
--INCLUDE ([SalesAmount])
--GO

--DROP INDEX [dbo].[factinternetsales].[NCIX_PointQuery]