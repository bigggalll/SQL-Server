-- Using a Local Server Group, Open a multi-server connection

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

EXEC [sp_spaceused] '[dbo].[factinternetsales]';
GO