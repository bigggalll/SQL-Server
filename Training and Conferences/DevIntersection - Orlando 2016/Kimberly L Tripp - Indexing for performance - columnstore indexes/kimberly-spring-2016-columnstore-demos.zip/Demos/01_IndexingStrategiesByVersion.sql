/*============================================================================
  File:     01_IndexingStrategiesByVersion.sql

  Summary:  This is the script that setups up the different indexing strategies
            that are possible across the versions (in the MODIFIED AdventureWorksDW2008
            sample database) on 2008 R2, 2012, 2014, and 2016.
  
  SQL Server Version: 2008 R2+
------------------------------------------------------------------------------
  Written by Kimberly L. Tripp, SQLskills.com

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  This script is intended only as a supplement to demos and lectures
  given by Kimberly L. Tripp.  
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

-- Demo Setup

-- ***********************************************************************
-- You must go through the SETUP scripts first.
-- SQLCMD: 01_SetupAdventureWorksDW2008_ModifiedSalesKey_AllServers.sql
-- SQLCMD: 02_ConfirmAllServersSetup.sql
-- ***********************************************************************

-- When you're ready to run, make sure you set that this is a 
-- SQLCMD script (Use the Query drop-down, select SQLCMD mode)

-- Demo Setup

----------------------------------------------------------------
-- SQL Server 2008 R2
----------------------------------------------------------------

:CONNECT (local)\SQL2008R2Dev
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

-- Nothing to do here... only CL / NC indexes

----------------------------------------------------------------
-- SQL Server 2012
----------------------------------------------------------------

-- Going to ADD a NONCLUSTERED Columnstore index

:CONNECT (local)\SQL2012Dev
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

-- Add a nonclustered columnstore index
CREATE NONCLUSTERED COLUMNSTORE INDEX [NCCI_Factinternetsales]
    ON [dbo].[factinternetsales]
        ( ProductKey
		 , OrderDateKey
		 , DueDateKey
		 , ShipDateKey
		 , CustomerKey
		 , PromotionKey
		 , CurrencyKey
		 , SalesTerritoryKey
		 , SalesOrderNumber
		 , SalesOrderLineNumber
		 , RevisionNumber
		 , OrderQuantity
		 , UnitPrice
		 , ExtendedAmount
		 , UnitPriceDiscountPct
		 , DiscountAmount
		 , ProductStandardCost
		 , TotalProductCost
		 , SalesAmount
		 , TaxAmt
		 , Freight
		 , CarrierTrackingNumber
		 , CustomerPONumber );
GO 


----------------------------------------------------------------
-- SQL Server 2014
----------------------------------------------------------------

:CONNECT (local)\SQL2014Dev
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

----------------------------------------------------------------
-- Change to a CLUSTERED Columnstore
----------------------------------------------------------------

-- We *THINK* we can just disable the nonclustered indexes
ALTER INDEX [IX_FactInternetSales_CurrencyKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_CustomerKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_ProductKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_PromotionKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_ShipDateKey] ON [dbo].[factinternetsales] DISABLE;
GO

-- You can't "DROP_EXISTING" on a PK... so, we have to drop
ALTER TABLE [dbo].[factinternetsales]
DROP CONSTRAINT [PK_FactInternetSales_SalesOrderNumber_SalesOrderLineNumber];
GO

--CREATE CLUSTERED COLUMNSTORE INDEX [IX_factinternetsales_CCSI]
--    ON [dbo].[factinternetsales];
GO -- FAILS, why? Constraints... Can we live without them? Possible if mostly RO?

-- First:
--Msg 35361, Level 16, State 0, Line 83
--CREATE INDEX statement failed. A clustered columnstore index cannot be created over referencing column 'FK_FactInternetSales_DimSalesTerritory' on table 'factinternetsales'.


-- OK, so let's drop those...
ALTER TABLE [dbo].[factinternetsales]
DROP CONSTRAINT [FK_FactInternetSales_DimSalesTerritory];
GO

ALTER TABLE [dbo].[factinternetsales]
DROP CONSTRAINT [FK_FactInternetSales_DimPromotion];
GO

ALTER TABLE [dbo].[factinternetsales]
DROP CONSTRAINT [FK_FactInternetSales_DimCurrency];
GO

ALTER TABLE [dbo].[factinternetsales]
DROP CONSTRAINT [FK_FactInternetSales_DimCustomer];
GO

ALTER TABLE [dbo].[factinternetsales]
DROP CONSTRAINT [FK_FactInternetSales_DimProduct];
GO

--CREATE CLUSTERED COLUMNSTORE INDEX [IX_factinternetsales_CCSI]
--    ON [dbo].[factinternetsales];
GO -- FAILS
--Msg 35304, Level 16, State 1, Line 104
--CREATE INDEX statement failed because a clustered columnstore index cannot be created on a table that has a nonclustered index. Consider dropping all nonclustered indexes and trying again.

DROP INDEX [dbo].[factinternetsales].[IX_FactInternetSales_CurrencyKey];
DROP INDEX [dbo].[factinternetsales].[IX_FactInternetSales_CustomerKey];
DROP INDEX [dbo].[factinternetsales].[IX_FactInternetSales_DueDateKey];
DROP INDEX [dbo].[factinternetsales].[IX_FactInternetSales_ProductKey];
DROP INDEX [dbo].[factinternetsales].[IX_FactInternetSales_PromotionKey];
DROP INDEX [dbo].[factinternetsales].[IX_FactInternetSales_ShipDateKey];
DROP INDEX [dbo].[factinternetsales].[IX_FactInternetSales_OrderDateKey];
GO

CREATE CLUSTERED COLUMNSTORE INDEX [IX_factinternetsales_CCSI]
    ON [dbo].[factinternetsales];
GO 

EXEC [sp_helpindex] '[dbo].[factinternetsales]';
GO 

-- OK, so... why is this different than 2012
-- 2014's read-write (but with no constraints)
-- 2014 doesn't require a row-store copy of the base data 
--  + This can drastically reduce overhead if you MOSTLY need
--    the CCSI and don't really need the others BUT, still want
--    to occasionally update the data. 

----------------------------------------------------------------
-- SQL Server 2016
----------------------------------------------------------------

:CONNECT (local)\SQL2016Dev
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

----------------------------------------------------------------
-- Make it a CLUSTERED Columnstore
----------------------------------------------------------------

-- Now, we can JUST disable the nonclustered indexes
ALTER INDEX [IX_FactInternetSales_CurrencyKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_CustomerKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_ProductKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_PromotionKey] ON [dbo].[factinternetsales] DISABLE;
ALTER INDEX [IX_FactInternetSales_ShipDateKey] ON [dbo].[factinternetsales] DISABLE;
GO

-- You can't "DROP_EXISTING" on a PK... so, we have to drop
ALTER TABLE [dbo].[factinternetsales]
DROP CONSTRAINT [PK_FactInternetSales_SalesOrderNumber_SalesOrderLineNumber];
GO

CREATE CLUSTERED COLUMNSTORE INDEX [IX_factinternetsales_CCSI]
    ON [dbo].[factinternetsales];
GO -- SUCCESS!

-- SQL Server 2016 allows constraints AND nonclustered indexes!

-- Rebuild the NC indexes... 
ALTER INDEX [IX_FactInternetSales_CurrencyKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_CustomerKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_ProductKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_PromotionKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_ShipDateKey] ON [dbo].[factinternetsales] REBUILD;
GO

-- WAIT - the NC indexes are actually different and may cover different queries!
-- So... it might not be good enough to just DISABLE / REBUILD
-- you *might* have to recreate these nonclustered indexes WITH the clustered index
-- as either an include (if the NC was UNIEUQ) or as part of the key is the NC
-- was NON-UNIQUE.

EXEC [sp_helpindex] '[dbo].[factinternetsales]';
GO 

