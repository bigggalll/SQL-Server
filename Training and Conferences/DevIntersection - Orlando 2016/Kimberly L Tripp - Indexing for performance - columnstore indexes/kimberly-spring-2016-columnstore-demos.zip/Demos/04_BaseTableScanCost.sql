DBCC DROPCLEANBUFFERS;
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

SET STATISTICS IO ON;
GO

DECLARE @StartTime datetime2 = sysdatetime();
SELECT COUNT(*) AS 'RowCount'
FROM [dbo].[factinternetsales] AS [fis] WITH (INDEX(0));
SELECT 'QueryExecutionTime' = datediff(ms, @StartTime, sysdatetime());
GO