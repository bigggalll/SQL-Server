-- Using a Local Server Group, Open a multi-server connection

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

SELECT [si].* 
FROM [sys].[indexes] AS [si]
WHERE [si].[OBJECT_ID] = OBJECT_ID('[dbo].[factinternetsales]')
ORDER BY [si].[index_id]
GO

--EXEC [sp_helpindex] '[dbo].[factinternetsales]';
--GO