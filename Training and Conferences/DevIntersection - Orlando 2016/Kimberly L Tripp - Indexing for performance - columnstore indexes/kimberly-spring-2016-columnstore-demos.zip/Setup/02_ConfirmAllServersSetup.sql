/*============================================================================
  File:     02_ConfirmAllServersSetup.sql

  Summary:  This confirms that the MODIFIED AdventureWorksDW2008
            sample database has been restored and has the correct 
            number of rows (30,923,776 rows).
  
  SQL Server Version: 2008 R2+
------------------------------------------------------------------------------
  Written by Kimberly L. Tripp, SQLskills.com

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  This script is intended only as a supplement to demos and lectures
  given by Kimberly L. Tripp.  
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

-- Demo Setup
-- make sure you set that this is a SQLCMD script 
-- (Use the Query drop-down, select SQLCMD mode)

:ON ERROR EXIT
GO

----------------------------------------------------------------
-- SQL Server 2008 R2
----------------------------------------------------------------

:CONNECT (local)\SQL2008R2Dev
GO

USE [master];
GO

IF (SELECT OBJECT_ID('[AdventureWorksDW2008_ModifiedSalesKey].[dbo].[factinternetsales]')) IS NULL
	RAISERROR ('Object failure on server: %s', 16, 1, @@servername)
ELSE
	SELECT @@servername
		, (SELECT count(*) FROM [AdventureWorksDW2008_ModifiedSalesKey].[dbo].[factinternetsales]) AS 'RowCount'
		, @@version;
GO

----------------------------------------------------------------
-- SQL Server 2012
----------------------------------------------------------------

:CONNECT (local)\SQL2012Dev
GO

USE [master];
GO

USE [master];
GO

IF (SELECT OBJECT_ID('[AdventureWorksDW2008_ModifiedSalesKey].[dbo].[factinternetsales]')) IS NULL
	RAISERROR ('Object failure on server: %s', 16, 1, @@servername)
ELSE
	SELECT @@servername
		, (SELECT count(*) FROM [AdventureWorksDW2008_ModifiedSalesKey].[dbo].[factinternetsales]) AS 'RowCount'
		, @@version;
GO

----------------------------------------------------------------
-- SQL Server 2014
----------------------------------------------------------------

:CONNECT (local)\SQL2014Dev
GO

USE [master];
GO

USE [master];
GO

IF (SELECT OBJECT_ID('[AdventureWorksDW2008_ModifiedSalesKey].[dbo].[factinternetsales]')) IS NULL
	RAISERROR ('Object failure on server: %s', 16, 1, @@servername)
ELSE
	SELECT @@servername
		, (SELECT count(*) FROM [AdventureWorksDW2008_ModifiedSalesKey].[dbo].[factinternetsales]) AS 'RowCount'
		, @@version;
GO

----------------------------------------------------------------
-- SQL Server 2016
----------------------------------------------------------------

:CONNECT (local)\SQL2016Dev
GO

USE [master];
GO

IF (SELECT OBJECT_ID('[AdventureWorksDW2008_ModifiedSalesKey].[dbo].[factinternetsales]')) IS NULL
	RAISERROR ('Object failure on server: %s', 16, 1, @@servername)
ELSE
	SELECT @@servername
		, (SELECT count(*) FROM [AdventureWorksDW2008_ModifiedSalesKey].[dbo].[factinternetsales]) AS 'RowCount'
		, @@version;
GO
