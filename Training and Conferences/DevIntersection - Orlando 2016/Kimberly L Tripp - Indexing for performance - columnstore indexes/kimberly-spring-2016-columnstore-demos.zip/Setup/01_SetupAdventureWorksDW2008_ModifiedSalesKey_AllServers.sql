/*============================================================================
  File:     01_SetupAdventureWorksDW2008_ModifiedSalesKey_AllServers.sql

  Summary:  This is the script that restores the MODIFIED AdventureWorksDW2008
            sample database to 2008 R2, 2012, 2014, and 2016.
  
  SQL Server Version: 2008 R2+
------------------------------------------------------------------------------
  Written by Kimberly L. Tripp, SQLskills.com

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  This script is intended only as a supplement to demos and lectures
  given by Kimberly L. Tripp.  
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

-- Demo Setup
-- ALL Servers (2008R2, 2012, 2014, and 2016)
-- CAN use this same 2008 R2 backup (Yeah!)

-- Start by downloading this SQL Server 2008R2 backup zip
-- here: https://www.dropbox.com/s/duzaop94ir3vfb7/AdventureWorksDW2008_SS2008R2.bak?dl=0

-- Next modify each section in this script so that the:
--  * server connections are correct
--  * backup location / path is correct
--  * database restore locations / paths are correct (for both data and log)

-- When you're ready to run, make sure you set that this is a 
-- SQLCMD script (Use the Query drop-down, select SQLCMD mode)

----------------------------------------------------------------
-- SQL Server 2008 R2
----------------------------------------------------------------

-- Restore the AdventureWorksDW2008_ModifiedSalesKey

:CONNECT (local)\SQL2008R2Dev
GO

USE [master];
GO

SELECT @@servername, @@version;
GO

RESTORE DATABASE [AdventureWorksDW2008_ModifiedSalesKey] 
FROM  DISK = N'D:\SQLskills\SampleDBs\AdventureWorksDW2008_SS2008R2.bak' 
WITH  
	  MOVE N'AdventureWorksDW2008_Data' TO N'D:\Microsoft SQL Server\MSSQL10_50.SQL2008R2DEV\MSSQL\DATA\AdventureWorksDW2008_ModifiedSalesKey_Data.mdf'
	, MOVE N'AdventureWorksDW2008_Log' TO N'D:\Microsoft SQL Server\MSSQL10_50.SQL2008R2DEV\MSSQL\DATA\AdventureWorksDW2008_ModifiedSalesKey_Log.LDF'
	, FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 5;
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

-- Rebuild ALL NC indexes from the smaller restored database:
ALTER INDEX [IX_FactInternetSales_CurrencyKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_CustomerKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_ProductKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_PromotionKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_ShipDateKey] ON [dbo].[factinternetsales] REBUILD;
GO

----------------------------------------------------------------
-- SQL Server 2012
----------------------------------------------------------------

:CONNECT (local)\SQL2012Dev
GO

USE [master];
GO

SELECT @@servername, @@version;
GO

RESTORE DATABASE [AdventureWorksDW2008_ModifiedSalesKey] 
FROM  DISK = N'D:\SQLskills\SampleDBs\AdventureWorksDW2008_SS2008R2.bak' 
WITH  
	  MOVE N'AdventureWorksDW2008_Data' TO N'D:\Microsoft SQL Server\MSSQL11.SQL2012DEV\MSSQL\DATA\AdventureWorksDW2008_ModifiedSalesKey_Data.mdf'
	, MOVE N'AdventureWorksDW2008_Log' TO N'D:\Microsoft SQL Server\MSSQL11.SQL2012DEV\MSSQL\DATA\AdventureWorksDW2008_ModifiedSalesKey_Log.LDF'
	, FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 5;
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

-- Rebuild ALL NC indexes from the smaller restored database:
ALTER INDEX [IX_FactInternetSales_CurrencyKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_CustomerKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_ProductKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_PromotionKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_ShipDateKey] ON [dbo].[factinternetsales] REBUILD;
GO

----------------------------------------------------------------
-- SQL Server 2014
----------------------------------------------------------------

:CONNECT (local)\SQL2014Dev
GO

USE [master];
GO

SELECT @@servername, @@version;
GO

RESTORE DATABASE [AdventureWorksDW2008_ModifiedSalesKey] 
FROM  DISK = N'D:\SQLskills\SampleDBs\AdventureWorksDW2008_SS2008R2.bak' 
WITH  
	  MOVE N'AdventureWorksDW2008_Data' TO N'D:\Microsoft SQL Server\MSSQL12.SQL2014DEV\MSSQL\DATA\AdventureWorksDW2008_ModifiedSalesKey_Data.mdf'
	, MOVE N'AdventureWorksDW2008_Log' TO N'D:\Microsoft SQL Server\MSSQL12.SQL2014DEV\MSSQL\DATA\AdventureWorksDW2008_ModifiedSalesKey_Log.LDF'
	, FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 5;
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

-- Rebuild ALL NC indexes from the smaller restored database:
ALTER INDEX [IX_FactInternetSales_CurrencyKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_CustomerKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_ProductKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_PromotionKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_ShipDateKey] ON [dbo].[factinternetsales] REBUILD;
GO

----------------------------------------------------------------
-- SQL Server 2016
----------------------------------------------------------------

:CONNECT (local)\SQL2016Dev
GO

USE [master];
GO

SELECT @@servername, @@version;
GO

RESTORE DATABASE [AdventureWorksDW2008_ModifiedSalesKey] 
-- It looks like they ARE going to support backup / restore more than 2 versions!
-- This is great! You can use the SQL Server 2008 R2 backup for SQL 2016 as well!!
FROM  DISK = N'D:\SQLskills\SampleDBs\AdventureWorksDW2008_SS2008R2.bak' 
WITH  
	  MOVE N'AdventureWorksDW2008_Data' TO N'D:\Microsoft SQL Server\MSSQL13.SQL2016DEV\MSSQL\DATA\AdventureWorksDW2008_ModifiedSalesKey_Data.mdf'
	, MOVE N'AdventureWorksDW2008_Log' TO N'D:\Microsoft SQL Server\MSSQL13.SQL2016DEV\MSSQL\DATA\AdventureWorksDW2008_ModifiedSalesKey_Log.LDF'
	, FILE = 1,  NOUNLOAD,  REPLACE,  STATS = 5;
GO

USE [AdventureWorksDW2008_ModifiedSalesKey];
GO

-- Rebuild ALL NC indexes from the smaller restored database:
ALTER INDEX [IX_FactInternetSales_CurrencyKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_CustomerKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_ProductKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_DueDateKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_PromotionKey] ON [dbo].[factinternetsales] REBUILD;
ALTER INDEX [IX_FactInternetSales_ShipDateKey] ON [dbo].[factinternetsales] REBUILD;
GO