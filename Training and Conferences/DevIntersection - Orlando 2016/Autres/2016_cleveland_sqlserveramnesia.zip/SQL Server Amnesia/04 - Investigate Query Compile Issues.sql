/***************************************************************************** 
* 
*   Summary: Demonstrates how to investigate compilation memory issues 
*         
*   Date: June 4, 2012 
* 
*   SQL Server Versions: 
*         2008, 2008 R2, 2012 
*         
****************************************************************************** 
*   Copyright (C) 2011 Jonathan M. Kehayias, SQLskills.com 
*   All rights reserved. 
* 
*   For more scripts and sample code, check out 
*      http://sqlskills.com/blogs/jonathan 
* 
*   You may alter this code for your own *non-commercial* purposes. You may 
*   republish altered code as long as you include this copyright and give 
*    due credit. 
* 
* 
*   THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
*   ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
*   TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
*   PARTICULAR PURPOSE. 
* 
******************************************************************************/ 


-- Waiting tasks with CompileMemory requirements
WITH XMLNAMESPACES 
   (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan') 
SELECT 
	c.value('(@CompileMemory)[1]', 'int') AS CompileMemory_KB,
	wt.session_id,
	wt.wait_type,
	wt.wait_duration_ms
FROM sys.dm_os_waiting_tasks AS wt
JOIN sys.dm_exec_sessions AS es
	ON wt.session_id = es.session_id
JOIN sys.dm_exec_requests AS er
	ON es.session_id = er.session_id
CROSS APPLY sys.dm_exec_query_plan(er.plan_handle) AS qp
CROSS APPLY qp.query_plan.nodes('//QueryPlan') AS n(c)
WHERE es.is_user_process = 1
  AND wt.wait_type = 'RESOURCE_SEMAPHORE_QUERY_COMPILE';
  
-- Compilation Gateway information
DBCC MEMORYSTATUS;
