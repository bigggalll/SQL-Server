-- Reproduce the memory leak fixed in CU4 to SP1 (https://support.microsoft.com/en-us/kb/3115789)
DECLARE @class tinyint,
      @class_desc nvarchar(60),
      @major_id int,
      @minor_id int,
      @grantee_principal_id int,
      @grantor_principal_id int,
      @type char(4),
      @permision_name nvarchar(128),
      @state char(1),
      @state_desc nvarchar(60);

WHILE 1=1 
BEGIN

      SELECT @class = class, @class_desc = class_desc, @major_id = major_id,
            @minor_id = minor_id, @grantee_principal_id = grantee_principal_id,
            @grantor_principal_id = grantor_principal_id, @type = type, 
            @permision_name = permission_name, @state = state, @state_desc = state_desc
      FROM sys.database_permissions
END
