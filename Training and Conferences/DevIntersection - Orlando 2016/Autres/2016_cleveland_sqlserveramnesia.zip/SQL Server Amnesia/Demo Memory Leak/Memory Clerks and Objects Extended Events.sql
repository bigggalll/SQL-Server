SELECT type, Sum(pages_kb)/1024. AS pages_MB 
FROM sys.dm_os_memory_clerks
GROUP BY type
ORDER BY pages_MB DESC

SELECT type, sum(pages_in_bytes)/1024./1024. AS pages_MB, count(*)
FROM sys.dm_os_memory_objects
GROUP BY type 
ORDER BY pages_MB DESC

SELECT CAST(memory_object_address AS BIGINT), * 
FROM sys.dm_os_memory_objects
WHERE type = 'MEMOBJ_SOSNODE';


-- Trace Flags required!
DBCC TRACESTATUS

-- 842 -  Bob Ward referenced this in his PASS2013 talk - tracks any buffer gets internally
--		  enables the sys.dm_os_memory_node_access_stats DMV and the page_reference_tracker XEvent
--		  (http://download.microsoft.com/download/d/b/d/dbde7972-1eb9-470a-ba18-58849db3eb3b/tshootperfprobs2008.docx)
--		  NOT FOR PRODUCTION USE - WILL SIGNIFICANTLY IMPACT PERFORMANCE!!!
-- 3654	- allow memory object allocation tracing (http://blogs.msdn.com/b/slavao/archive/2005/08/30/458036.aspx) 
--		  enables the dm_os_memory_allocations DMV and malloc_spy_memory_allocated/deallocated XEvents
--		  NOT FOR PRODUCTION USE - WILL SIGNIFICANTLY IMPACT PERFORMACNE!!!
-- 3656 - callstack resolution from XEvents event_file (http://sqlcat.com/sqlcat/b/msdnmirror/archive/2010/05/11/resolving-dtc-related-waits-and-tuning-scalability-of-dtc.aspx)


-- Requires 3654 to be enabled
SELECT * 
FROM sys.dm_os_memory_allocations
WHERE memory_object_address = 0x000000011F004040;


-- Track the usage down with Extended Events - Requires 3654 to be enabled!

CREATE EVENT SESSION [MEMOBJ_SOSNODE Tracing] ON SERVER 
ADD EVENT sqlos.ccccccc(
    ACTION(package0.callstack,sqlserver.sql_text)
    WHERE ([package0].[equal_uint64]([pmo_type],(2)) AND [pmo_address]=(4815077440.))),
ADD EVENT sqlos.malloc_spy_memory_freed(
    ACTION(package0.callstack,sqlserver.sql_text)
    WHERE ([package0].[equal_uint64]([pmo_type],(2)) AND [pmo_address]=(4815077440.)))
ADD TARGET package0.event_file(SET filename=N'MEMOBJ_SOSNODE Tracing')
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO



SELECT 
	event_name,	
	event_data.value('(event/@timestamp)[1]', 'varchar(128)') AS datetimestamp,
	event_data.value('(event/data[@name="address"]/value)[1]', 'varchar(128)') AS address,
	event_data.value('(event/data[@name="size"]/value)[1]', 'bigint') AS size,
	event_data.value('(event/data[@name="tag"]/value)[1]', 'varchar(128)') AS tag,
	event_data.value('(event/data[@name="allocation_stamp"]/value)[1]', 'varchar(128)') AS allocation_stamp,
	event_data.value('(event/data[@name="pmo_address"]/value)[1]', 'varchar(128)') AS pmo_address,
	event_data.value('(event/data[@name="pmo_type"]/text)[1]', 'varchar(128)') AS pmo_type,
	event_data.value('(event/action[@name="callstack"]/value)[1]', 'varchar(max)') AS callstack
FROM 
(
	SELECT object_name AS event_name, 
		CAST ([event_data] AS XML) AS event_data
	FROM sys.fn_xe_file_target_read_file
			(N'MEMOBJ_SOSNODE Tracing*.xel', NULL, NULL, NULL)
) AS tab
ORDER BY datetimestamp
OPTION(MAXDOP 1);
GO



