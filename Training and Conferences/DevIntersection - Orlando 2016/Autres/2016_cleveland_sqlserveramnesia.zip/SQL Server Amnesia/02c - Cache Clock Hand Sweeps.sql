/***************************************************************************** 
* 
*   Summary: Demonstrates how to query cache clock hand activity
*         
*   Date: June 4, 2012 
* 
*   SQL Server Versions: 
*         2008, 2008 R2 
*         
****************************************************************************** 
*   Copyright (C) 2011 Jonathan M. Kehayias, SQLskills.com 
*   All rights reserved. 
* 
*   For more scripts and sample code, check out 
*      http://sqlskills.com/blogs/jonathan 
* 
*   You may alter this code for your own *non-commercial* purposes. You may 
*   republish altered code as long as you include this copyright and give 
*    due credit. 
* 
* 
*   THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
*   ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
*   TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
*   PARTICULAR PURPOSE. 
* 
******************************************************************************/ 


-- Cache clock hands and last sweep info.
SELECT DISTINCT
	ch.clock_hand,
	ch.clock_status,
	cc.name,  
	cc.type, 
	cc.pages_kb,  
	cc.pages_in_use_kb,  
	cc.entries_count,  
	cc.entries_in_use_count,
	ch.rounds_count,
	ch.removed_all_rounds_count, 
	DATEADD (ss, (-1 * ((cpu_ticks / CONVERT (int, ( cpu_ticks / ms_ticks ))) - [round_start_time])/1000), GETDATE()) AS last_round_time, 
	ch.removed_last_round_count, last_tick_time, last_round_start_time, round_start_time,
	cpu_ticks, ms_ticks
FROM sys.dm_os_memory_cache_counters AS cc  
JOIN sys.dm_os_memory_cache_clock_hands AS ch 
	ON cc.cache_address =ch.cache_address
CROSS JOIN sys.dm_os_sys_info
WHERE ch.removed_all_rounds_count > 0 
ORDER BY 
	DATEADD (ss, (-1 * ((cpu_ticks / CONVERT (int, ( cpu_ticks / ms_ticks ))) - [round_start_time])/1000), GETDATE()) DESC,
	removed_all_rounds_count DESC
