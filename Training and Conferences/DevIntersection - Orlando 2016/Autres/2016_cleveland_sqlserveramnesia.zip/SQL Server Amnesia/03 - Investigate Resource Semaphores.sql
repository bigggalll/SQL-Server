/***************************************************************************** 
* 
*   Summary: Demonstrates how to investigate resource_semaphore waits
*         
*   Date: June 4, 2012 
* 
*   SQL Server Versions: 
*         2008, 2008 R2, 2012 
*         
****************************************************************************** 
*   Copyright (C) 2011 Jonathan M. Kehayias, SQLskills.com 
*   All rights reserved. 
* 
*   For more scripts and sample code, check out 
*      http://sqlskills.com/blogs/jonathan 
* 
*   You may alter this code for your own *non-commercial* purposes. You may 
*   republish altered code as long as you include this copyright and give 
*    due credit. 
* 
* 
*   THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
*   ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
*   TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
*   PARTICULAR PURPOSE. 
* 
******************************************************************************/ 

-- Script to look at the waiting tasks
SELECT
	owt.session_id,
	owt.wait_duration_ms,
	owt.wait_type,
	owt.blocking_session_id,
	owt.resource_description,
	es.program_name,
	est.text,
	est.dbid,
	eqp.query_plan,
	es.cpu_time,
	es.memory_usage
FROM sys.dm_os_waiting_tasks owt
INNER JOIN sys.dm_exec_sessions es ON
	owt.session_id = es.session_id
INNER JOIN sys.dm_exec_requests er ON
	es.session_id = er.session_id
OUTER APPLY sys.dm_exec_sql_text (er.sql_handle) est
OUTER APPLY sys.dm_exec_query_plan (er.plan_handle) eqp
WHERE es.is_user_process = 1
OPTION(MAXDOP 1, RECOMPILE);
GO

-- Look at resource semaphore information
SELECT * 
FROM sys.dm_exec_query_resource_semaphores
WHERE pool_id = 2 AND
      resource_semaphore_id = 0
GO

-- Look at memory grant information
SELECT * 
FROM sys.dm_exec_query_memory_grants
ORDER BY grant_time, wait_order

select * from sys.dm_exec_requests

select * from sys.dm_os_wait_stats
where wait_type = 'Resource_semaphore'

dbcc memorystatus