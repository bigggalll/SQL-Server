/*****************************************************************************
*   Presentation: SQL Server Amnesia
*   FileName:  dm_os_ring_buffers.sql
*
*   Summary: Demonstrates how to parse the contents of sys.dm_os_ring_buffers.
*
*   Date: March 14, 2015 
*
*   SQL Server Versions:
*         2012, 2014
*         
******************************************************************************
*   Copyright (C) 2011 Jonathan M. Kehayias, SQLskills.com
*   All rights reserved. 
*
*   For more scripts and sample code, check out 
*      http://sqlskills.com/blogs/jonathan
*
*   You may alter this code for your own *non-commercial* purposes. You may
*   republish altered code as long as you include this copyright and give 
*	due credit. 
*
*
*   THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
*   ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
*   TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
*   PARTICULAR PURPOSE. 
*
******************************************************************************/


--System Memory Usage
SELECT  
    record.value('(/Record/@id)[1]', 'bigint') as [ID], 
    tab.timestamp,
    EventTime, 
    record.value('(/Record/ResourceMonitor/Notification)[1]', 'varchar(max)') as [Type], 
    record.value('(/Record/ResourceMonitor/IndicatorsProcess)[1]', 'bigint') as [IndicatorsProcess], 
    record.value('(/Record/ResourceMonitor/IndicatorsSystem)[1]', 'bigint') as [IndicatorsSystem],
    record.value('(/Record/ResourceMonitor/NodeId)[1]', 'bigint') as [NodeId],
    record.value('(/Record/MemoryNode/TargetMemory)[1]', 'bigint') as [SQL_TargetMemoryKB],
    record.value('(/Record/MemoryNode/ReservedMemory)[1]', 'bigint') as [SQL_ReservedMemoryKB],
    record.value('(/Record/MemoryNode/AWEMemory)[1]', 'bigint') as [SQL_AWEMemoryKB],
    record.value('(/Record/MemoryNode/PagesMemory)[1]', 'bigint') as [SQL_PagesMemoryKB],
    record.value('(/Record/MemoryRecord/MemoryUtilization)[1]', 'bigint') AS [MemoryUtilization%], 
    record.value('(/Record/MemoryRecord/AvailablePhysicalMemory)[1]', 'bigint') AS [AvailablePhysicalMemoryKB], 
    record.value('(/Record/ResourceMonitor/Effect[@type="APPLY_LOWPM"]/@state)[1]', 'nvarchar(50)') as [APPLY_LOWPM_State],
    record.value('(/Record/ResourceMonitor/Effect[@type="APPLY_LOWPM"]/@reversed)[1]', 'bit') as [APPLY_LOWPM_Reversed],
    record.value('(/Record/ResourceMonitor/Effect[@type="APPLY_LOWPM"])[1]', 'bigint') as [APPLY_LOWPM_Time],
    record.value('(/Record/ResourceMonitor/Effect[@type="APPLY_HIGHPM"]/@state)[1]', 'nvarchar(50)') as [APPLY_HIGHPM_State],
    record.value('(/Record/ResourceMonitor/Effect[@type="APPLY_HIGHPM"]/@reversed)[1]', 'bit') as [APPLY_HIGHPM_Reversed],
    record.value('(/Record/ResourceMonitor/Effect[@type="APPLY_HIGHPM"])[1]', 'bigint') as [APPLY_HIGHPM_Time],
    record.value('(/Record/ResourceMonitor/Effect[@type="REVERT_HIGHPM"]/@state)[1]', 'nvarchar(50)') as [REVERT_HIGHPM_State],
    record.value('(/Record/ResourceMonitor/Effect[@type="REVERT_HIGHPM"]/@reversed)[1]', 'bit') as [REVERT_HIGHPM_Reversed],
    record.value('(/Record/ResourceMonitor/Effect[@type="REVERT_HIGHPM"])[1]', 'bigint') as [REVERT_HIGHPM_Time],
    record.value('(/Record/MemoryRecord/TotalPhysicalMemory)[1]', 'bigint') AS [TotalPhysicalMemoryKB],
    record.value('(/Record/MemoryRecord/TotalPageFile)[1]', 'bigint') AS [TotalPageFileKB], 
    record.value('(/Record/MemoryRecord/AvailablePageFile)[1]', 'bigint') AS [AvailablePageFileKB],
    record.value('(/Record/MemoryRecord/TotalVirtualAddressSpace)[1]', 'bigint') AS [TotalVirtualAddressSpaceKB], 
    record.value('(/Record/MemoryRecord/AvailableVirtualAddressSpace)[1]', 'bigint') AS [AvailableVirtualAddressSpaceKB],
    record.value('(/Record/MemoryRecord/AvailableExtendedVirtualAddressSpace)[1]', 'bigint') AS [AvailableExtendedVirtualAddressSpaceKB]
FROM ( 
    SELECT 
		[timestamp],
        DATEADD (ss, (-1 * ((cpu_ticks / CONVERT (float, ( cpu_ticks / ms_ticks ))) - [timestamp])/1000), GETDATE()) AS EventTime, 
        CONVERT (xml, record) AS record 
    FROM sys.dm_os_ring_buffers 
    CROSS JOIN sys.dm_os_sys_info 
    WHERE ring_buffer_type = 'RING_BUFFER_RESOURCE_MONITOR') AS tab 
ORDER BY ID DESC;
